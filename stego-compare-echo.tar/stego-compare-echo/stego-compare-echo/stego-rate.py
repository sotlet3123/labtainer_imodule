import numpy as np
import soundfile as sf

def calculate_snr(original, modified):
    noise = original - modified
    signal_power = np.mean(original ** 2)
    noise_power = np.mean(noise ** 2)
    if noise_power == 0:
        return float('inf')
    return 10 * np.log10(signal_power / noise_power)

def calculate_psnr(original, modified):
    mse = np.mean((original - modified) ** 2)
    if mse == 0:
        return float('inf')
    max_val = np.max(np.abs(original))
    return 20 * np.log10(max_val / np.sqrt(mse))

def calculate_mse(original, modified):
    return np.mean((original - modified) ** 2)

def load_audio(file_path):
    data, samplerate = sf.read(file_path)
    if len(data.shape) == 2:
        data = data.mean(axis=1)
    return data

def compare_audio(original_path, modified_path):
    original = load_audio(original_path)
    modified = load_audio(modified_path)

    min_len = min(len(original), len(modified))
    original = original[:min_len]
    modified = modified[:min_len]

    snr = calculate_snr(original, modified)
    psnr = calculate_psnr(original, modified)
    mse = calculate_mse(original, modified)

    print("Compare successfully! Here is the result:")
    print(f"MSE  : {mse:.6f}")
    print(f"SNR  : {snr:.2f} dB")
    print(f"PSNR : {psnr:.2f} dB")

if __name__ == "__main__":
    original_audio = ""
    stego_audio = ""
    compare_audio(original_audio, stego_audio)

