import numpy as np
import matplotlib.pyplot as plt
from scipy.io import wavfile

file_single = 'output_single.wav'
file_mirror = 'output_mirror.wav'
file_bf     = 'output_bf.wav'

start_sec = 0
duration_sec = 0.01

rate, data_single = wavfile.read(file_single)
rate, data_mirror = wavfile.read(file_mirror)
rate, data_bf     = wavfile.read(file_bf)

if len(data_single.shape) == 2:
    data_single = data_single.mean(axis=1)
if len(data_mirror.shape) == 2:
    data_mirror = data_mirror.mean(axis=1)
if len(data_bf.shape) == 2:
    data_bf = data_bf.mean(axis=1)

start_sample = int(start_sec * rate)
N = int(duration_sec * rate)

seg_single = data_single[start_sample:start_sample+N]
seg_mirror = data_mirror[start_sample:start_sample+N]
seg_bf     = data_bf[start_sample:start_sample+N]

min_len = min(len(seg_single), len(seg_mirror), len(seg_bf))
seg_single = seg_single[:min_len]
seg_mirror = seg_mirror[:min_len]
seg_bf     = seg_bf[:min_len]

f = np.fft.rfftfreq(min_len, d=1/rate)
spectrum_single = np.abs(np.fft.rfft(seg_single))
spectrum_mirror = np.abs(np.fft.rfft(seg_mirror))
spectrum_bf     = np.abs(np.fft.rfft(seg_bf))

plt.figure(figsize=(10,6))
plt.semilogy(f, spectrum_single, label='Echo Single', linewidth=1.5)
plt.semilogy(f, spectrum_mirror, label='Echo Mirror', linewidth=1.5)
plt.semilogy(f, spectrum_bf, label='Echo BF', linewidth=1.5)
plt.xlabel('Frequency (Hz)')
plt.ylabel('Amplitude (log)')
plt.title(f'Frequency spectrum Comparison starts at {start_sec}s, longs {duration_sec}s')
plt.legend()
plt.tight_layout()
plt.savefig('compare_hide_spectrum.png', dpi=300)
plt.close()

print("Saved in compare_hide_spectrum.png")
