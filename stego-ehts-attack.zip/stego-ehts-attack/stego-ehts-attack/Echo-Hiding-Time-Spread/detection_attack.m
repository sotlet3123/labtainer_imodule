% TẤN CÔNG PHÁT HIỆN THÔNG TIN GIẤU TIN
close all; clear all; clc;

% Kiểm tra và tải gói signal nếu có
has_signal_pkg = false;
try
    pkg('list');
    if exist('pkg') == 5 % function exists
        pkg_list = pkg('list');
        is_signal_installed = false;
        for i = 1:length(pkg_list)
            if strcmp(pkg_list{i}.name, 'signal')
                is_signal_installed = true;
                has_signal_pkg = true;
                if ~pkg_list{i}.loaded
                    pkg('load', 'signal');
                    fprintf('Đã tải gói signal.\n');
                end
                break;
            end
        end
        if ~is_signal_installed
            fprintf('Cảnh báo: Gói signal không được cài đặt. Sẽ sử dụng các hàm tự cài đặt.\n');
        end
    end
catch
    fprintf('Cảnh báo: Không thể kiểm tra/tải gói signal. Sẽ sử dụng các hàm tự cài đặt.\n');
end

% Hiển thị tiêu đề
fprintf('===== TẤN CÔNG PHÁT HIỆN THÔNG TIN GIẤU TIN =====\n\n');
fprintf('Chương trình này thực hiện các phương pháp thống kê và phân tích để phát hiện sự hiện diện\n');
fprintf('của thông tin giấu tin trong file âm thanh, đặc biệt là phương pháp Echo Hiding.\n\n');

% Cho phép người dùng chọn file âm thanh nghi ngờ có giấu tin
fprintf('Chọn file âm thanh nghi ngờ có giấu tin từ thư mục audio_out...\n');
[stego_name, stego_path] = uigetfile({'*.wav;*.mp3;*.flac;*.ogg;*.aac', 'Audio Files (*.wav, *.mp3, *.flac, *.ogg, *.aac)'}, 'Chọn file âm thanh nghi ngờ có giấu tin', 'audio_out/');

% Kiểm tra xem người dùng đã chọn file hay chưa
if isequal(stego_name, 0)
    fprintf('Người dùng đã hủy việc chọn file.\n');
    return;
end

% Hiển thị thông tin file đã chọn
fprintf('\nĐã chọn file nghi ngờ: %s\n', fullfile(stego_path, stego_name));

% Đọc dữ liệu âm thanh nghi ngờ
fprintf('\nĐang đọc dữ liệu âm thanh...\n');
try
    [stego_data, fs] = audioread(fullfile(stego_path, stego_name));
    fprintf('Đã đọc dữ liệu âm thanh thành công. Tần số lấy mẫu: %d Hz\n', fs);
catch ME
    fprintf('Lỗi khi đọc file âm thanh: %s\n', ME.message);
    return;
end

% Hỏi người dùng có muốn so sánh với file âm thanh gốc không
choice = input('\nBạn có muốn so sánh với file âm thanh gốc không? (y/n): ', 's');

if strcmpi(choice, 'y')
    % Cho phép người dùng chọn file âm thanh gốc
    fprintf('\nChọn file âm thanh gốc từ thư mục audio_in...\n');
    [orig_name, orig_path] = uigetfile({'*.wav;*.mp3;*.flac;*.ogg;*.aac', 'Audio Files (*.wav, *.mp3, *.flac, *.ogg, *.aac)'}, 'Chọn file âm thanh gốc', 'audio_in/');
    
    % Kiểm tra xem người dùng đã chọn file hay chưa
    if isequal(orig_name, 0)
        fprintf('Người dùng đã hủy việc chọn file gốc. Tiếp tục chỉ với file nghi ngờ.\n');
        has_original = false;
    else
        % Hiển thị thông tin file đã chọn
        fprintf('\nĐã chọn file gốc: %s\n', fullfile(orig_path, orig_name));
        
        % Đọc dữ liệu âm thanh gốc
        fprintf('\nĐang đọc dữ liệu âm thanh gốc...\n');
        try
            [orig_data, orig_fs] = audioread(fullfile(orig_path, orig_name));
            
            % Kiểm tra tần số lấy mẫu
            if orig_fs ~= fs
                fprintf('Cảnh báo: Hai file có tần số lấy mẫu khác nhau (%d Hz và %d Hz).\n', fs, orig_fs);
                fprintf('Đang chuyển đổi file gốc để phù hợp với tần số lấy mẫu của file nghi ngờ...\n');
                orig_data = resample(orig_data, fs, orig_fs);
            end
            
            has_original = true;
            fprintf('Đã đọc dữ liệu âm thanh gốc thành công.\n');
        catch ME
            fprintf('Lỗi khi đọc file âm thanh gốc: %s\n', ME.message);
            fprintf('Tiếp tục chỉ với file nghi ngờ.\n');
            has_original = false;
        end
    end
else
    has_original = false;
    fprintf('\nTiếp tục chỉ với file nghi ngờ.\n');
end

% Đảm bảo dữ liệu là mono để phân tích
if size(stego_data, 2) > 1
    fprintf('\nPhát hiện tín hiệu stereo. Chuyển đổi thành mono để phân tích...\n');
    stego_data = mean(stego_data, 2);
end

if has_original && size(orig_data, 2) > 1
    orig_data = mean(orig_data, 2);
end

% Đảm bảo cùng độ dài
if has_original
    min_length = min(length(stego_data), length(orig_data));
    stego_data = stego_data(1:min_length);
    orig_data = orig_data(1:min_length);
end

% Chuẩn hóa dữ liệu
stego_data = stego_data / max(abs(stego_data));
if has_original
    orig_data = orig_data / max(abs(orig_data));
end

fprintf('\n===== THỰC HIỆN TẤN CÔNG PHÁT HIỆN =====\n');

% 1. Phương pháp thống kê cơ bản
fprintf('\n1. PHƯƠNG PHÁP THỐNG KÊ CƠ BẢN\n');

stego_mean = mean(stego_data);
stego_std = std(stego_data);

% Tính entropy của stego_data
nbins = min(256, length(stego_data));
[counts, ~] = hist(stego_data, nbins);
counts = counts / sum(counts);
counts = counts(counts > 0); % Loại bỏ các giá trị 0
stego_entropy = -sum(counts .* log2(counts));

% Tính kurtosis của stego_data
x = stego_data - mean(stego_data);
n = length(x);
m2 = sum(x.^2) / n;
m4 = sum(x.^4) / n;
if m2 > 0
    stego_kurtosis = m4 / (m2^2) - 3; % Excess kurtosis
else
    stego_kurtosis = 0;
end

% Tính skewness của stego_data
x = stego_data - mean(stego_data);
n = length(x);
m2 = sum(x.^2) / n;
m3 = sum(x.^3) / n;
if m2 > 0
    stego_skewness = m3 / (m2^(3/2));
else
    stego_skewness = 0;
end

fprintf('Chỉ số thống kê của file nghi ngờ:\n');
fprintf('- Giá trị trung bình: %.6f\n', stego_mean);
fprintf('- Độ lệch chuẩn: %.6f\n', stego_std);
fprintf('- Entropy: %.6f\n', stego_entropy);
fprintf('- Kurtosis: %.6f\n', stego_kurtosis);
fprintf('- Skewness: %.6f\n', stego_skewness);

if has_original
    orig_mean = mean(orig_data);
    orig_std = std(orig_data);
    
    % Tính entropy của orig_data
    nbins = min(256, length(orig_data));
    [counts, ~] = hist(orig_data, nbins);
    counts = counts / sum(counts);
    counts = counts(counts > 0); % Loại bỏ các giá trị 0
    orig_entropy = -sum(counts .* log2(counts));
    
    % Tính kurtosis của orig_data
    x = orig_data - mean(orig_data);
    n = length(x);
    m2 = sum(x.^2) / n;
    m4 = sum(x.^4) / n;
    if m2 > 0
        orig_kurtosis = m4 / (m2^2) - 3; % Excess kurtosis
    else
        orig_kurtosis = 0;
    end
    
    % Tính skewness của orig_data
    x = orig_data - mean(orig_data);
    n = length(x);
    m2 = sum(x.^2) / n;
    m3 = sum(x.^3) / n;
    if m2 > 0
        orig_skewness = m3 / (m2^(3/2));
    else
        orig_skewness = 0;
    end
    
    fprintf('\nChỉ số thống kê của file gốc:\n');
    fprintf('- Giá trị trung bình: %.6f\n', orig_mean);
    fprintf('- Độ lệch chuẩn: %.6f\n', orig_std);
    fprintf('- Entropy: %.6f\n', orig_entropy);
    fprintf('- Kurtosis: %.6f\n', orig_kurtosis);
    fprintf('- Skewness: %.6f\n', orig_skewness);
    
    fprintf('\nSự khác biệt:\n');
    fprintf('- Giá trị trung bình: %.6f (%.2f%%)\n', abs(stego_mean - orig_mean), 100*abs(stego_mean - orig_mean)/abs(orig_mean));
    fprintf('- Độ lệch chuẩn: %.6f (%.2f%%)\n', abs(stego_std - orig_std), 100*abs(stego_std - orig_std)/abs(orig_std));
    fprintf('- Entropy: %.6f (%.2f%%)\n', abs(stego_entropy - orig_entropy), 100*abs(stego_entropy - orig_entropy)/abs(orig_entropy));
    fprintf('- Kurtosis: %.6f (%.2f%%)\n', abs(stego_kurtosis - orig_kurtosis), 100*abs(stego_kurtosis - orig_kurtosis)/abs(orig_kurtosis));
    fprintf('- Skewness: %.6f (%.2f%%)\n', abs(stego_skewness - orig_skewness), 100*abs(stego_skewness - orig_skewness)/abs(orig_skewness));
end

% 2. Kiểm tra phương pháp Echo Hiding
fprintf('\n2. KIỂM TRA PHƯƠNG PHÁP ECHO HIDING\n');

% Tính cepstrum của tín hiệu
nfft = 2^nextpow2(length(stego_data));
stego_fft = fft(stego_data, nfft);
stego_log_spectrum = log(abs(stego_fft(1:nfft/2+1)) + eps);
stego_cepstrum = real(ifft(stego_log_spectrum));

% Giới hạn phân tích cepstrum cho quefrencies thấp (tương ứng với độ trễ echo)
ceps_limit = min(1000, length(stego_cepstrum));
quefrency = (0:ceps_limit-1) / fs * 1000; % Chuyển đổi sang ms

% Tìm các peak trong cepstrum
zoom_limit = min(find(quefrency >= 50), length(quefrency));
min_height = 0.1 * max(stego_cepstrum(1:zoom_limit)); % Ngưỡng chiều cao tối thiểu

% Tìm các peak
peaks = [];
peak_heights = [];
for i = 2:zoom_limit-1
    if stego_cepstrum(i) > stego_cepstrum(i-1) && stego_cepstrum(i) > stego_cepstrum(i+1) && stego_cepstrum(i) > min_height
        % Kiểm tra xem peak này có đủ xa so với peak trước không
        if isempty(peaks) || (quefrency(i) - quefrency(peaks(end)) >= 0.5)
            peaks = [peaks, i];
            peak_heights = [peak_heights, stego_cepstrum(i)];
        end
    end
end

% Hiển thị biểu đồ cepstrum
h1 = figure('Name', 'Phân tích Cepstrum để phát hiện Echo', 'NumberTitle', 'off', 'Position', [100 100 900 400]);
plot(quefrency(1:zoom_limit), stego_cepstrum(1:zoom_limit), 'b-', 'LineWidth', 1.2);
hold on;
% Đánh dấu các peak tìm được
if ~isempty(peaks)
    for i = 1:length(peaks)
        if peaks(i) <= zoom_limit
            plot(quefrency(peaks(i)), stego_cepstrum(peaks(i)), 'ro', 'MarkerSize', 8, 'LineWidth', 1.5);
            text(quefrency(peaks(i)), stego_cepstrum(peaks(i))*1.1, sprintf('%.2f ms', quefrency(peaks(i))), 'FontSize', 8);
        end
    end
end
hold off;
title('Cepstrum phát hiện Echo (0-50 ms)', 'FontWeight', 'bold');
xlabel('Quefrency (ms)', 'FontWeight', 'bold');
ylabel('Biên độ', 'FontWeight', 'bold');
grid on;
set(gca, 'FontSize', 10);

% Phân tích cepstrum nếu có file gốc
if has_original
    % Tính cepstrum của tín hiệu gốc
    orig_fft = fft(orig_data, nfft);
    orig_log_spectrum = log(abs(orig_fft(1:nfft/2+1)) + eps);
    orig_cepstrum = real(ifft(orig_log_spectrum));
    
    % Tính sự khác biệt cepstrum
    ceps_diff = stego_cepstrum - orig_cepstrum(1:length(stego_cepstrum));
    
    % Hiển thị biểu đồ so sánh
    h2 = figure('Name', 'So sánh Cepstrum', 'NumberTitle', 'off', 'Position', [150 150 900 600]);
    
    subplot(3, 1, 1);
    plot(quefrency(1:zoom_limit), stego_cepstrum(1:zoom_limit), 'b-', 'LineWidth', 1.2);
    title('Cepstrum của tín hiệu nghi ngờ', 'FontWeight', 'bold');
    xlabel('Quefrency (ms)', 'FontWeight', 'bold');
    ylabel('Biên độ', 'FontWeight', 'bold');
    grid on;
    set(gca, 'FontSize', 9);
    xlim([0 50]);
    
    subplot(3, 1, 2);
    plot(quefrency(1:zoom_limit), orig_cepstrum(1:zoom_limit), 'g-', 'LineWidth', 1.2);
    title('Cepstrum của tín hiệu gốc', 'FontWeight', 'bold');
    xlabel('Quefrency (ms)', 'FontWeight', 'bold');
    ylabel('Biên độ', 'FontWeight', 'bold');
    grid on;
    set(gca, 'FontSize', 9);
    xlim([0 50]);
    
    subplot(3, 1, 3);
    plot(quefrency(1:zoom_limit), ceps_diff(1:zoom_limit), 'r-', 'LineWidth', 1.2);
    title('Sự khác biệt Cepstrum (nghi ngờ - gốc)', 'FontWeight', 'bold');
    xlabel('Quefrency (ms)', 'FontWeight', 'bold');
    ylabel('Biên độ', 'FontWeight', 'bold');
    grid on;
    set(gca, 'FontSize', 9);
    xlim([0 50]);
    
    % Tìm các peak trong sự khác biệt cepstrum
    diff_peaks = [];
    diff_peak_heights = [];
    diff_min_height = 0.1 * max(abs(ceps_diff(1:zoom_limit))); % Ngưỡng chiều cao tối thiểu
    
    for i = 2:zoom_limit-1
        if abs(ceps_diff(i)) > abs(ceps_diff(i-1)) && abs(ceps_diff(i)) > abs(ceps_diff(i+1)) && abs(ceps_diff(i)) > diff_min_height
            % Kiểm tra xem peak này có đủ xa so với peak trước không
            if isempty(diff_peaks) || (quefrency(i) - quefrency(diff_peaks(end)) >= 0.5)
                diff_peaks = [diff_peaks, i];
                diff_peak_heights = [diff_peak_heights, ceps_diff(i)];
            end
        end
    end
    
    fprintf('\nSự khác biệt Cepstrum - Các đỉnh đáng chú ý:\n');
    for i = 1:length(diff_peaks)
        fprintf('- Đỉnh tại %.2f ms với biên độ %.6f\n', quefrency(diff_peaks(i)), diff_peak_heights(i));
    end
end

% Báo cáo các peak tìm được từ file nghi ngờ
fprintf('\nCác đỉnh Cepstrum đáng chú ý trên file nghi ngờ:\n');
for i = 1:length(peaks)
    fprintf('- Đỉnh tại %.2f ms với biên độ %.6f\n', quefrency(peaks(i)), peak_heights(i));
end

% 3. Phân tích thống kê khác biệt giữa các khung (frame)
fprintf('\n3. PHÂN TÍCH KHÁC BIỆT GIỮA CÁC KHUNG\n');

% Chia tín hiệu thành các khung nhỏ (8192 mẫu, giống như trong mã nguồn gốc)
frame_length = 8192;
num_frames = floor(length(stego_data) / frame_length);

% Tính SNR (Signal-to-Noise Ratio) giữa các khung liên tiếp
frame_snr = zeros(num_frames-1, 1);
for i = 1:num_frames-1
    frame1 = stego_data((i-1)*frame_length+1 : i*frame_length);
    frame2 = stego_data(i*frame_length+1 : (i+1)*frame_length);
    
    % Tính SNR giữa hai khung liên tiếp
    signal_power = sum(frame1.^2);
    noise = frame1 - frame2;
    noise_power = sum(noise.^2);
    if noise_power > 0
        frame_snr(i) = 10 * log10(signal_power / noise_power);
    else
        frame_snr(i) = 100; % Giá trị lớn nếu không có nhiễu
    end
end

% Tính độ lệch chuẩn của SNR giữa các khung
snr_std = std(frame_snr);
fprintf('Độ lệch chuẩn của SNR giữa các khung: %.6f dB\n', snr_std);

% Hiển thị biểu đồ SNR giữa các khung
h3 = figure('Name', 'SNR giữa các khung liên tiếp', 'NumberTitle', 'off', 'Position', [200 200 900 400]);
plot(1:num_frames-1, frame_snr, 'b-', 'LineWidth', 1.2);
title('SNR giữa các khung liên tiếp', 'FontWeight', 'bold');
xlabel('Số thứ tự khung', 'FontWeight', 'bold');
ylabel('SNR (dB)', 'FontWeight', 'bold');
grid on;
set(gca, 'FontSize', 10);

% Tính entropy của mỗi khung
frame_entropy = zeros(num_frames, 1);
for i = 1:num_frames
    frame = stego_data((i-1)*frame_length+1 : i*frame_length);
    
    % Tính entropy của frame
    nbins = min(256, length(frame));
    [counts, ~] = hist(frame, nbins);
    counts = counts / sum(counts);
    counts = counts(counts > 0); % Loại bỏ các giá trị 0
    frame_entropy(i) = -sum(counts .* log2(counts));
end

% Hiển thị biểu đồ entropy của các khung
h4 = figure('Name', 'Entropy của các khung', 'NumberTitle', 'off', 'Position', [250 250 900 400]);
plot(1:num_frames, frame_entropy, 'r-', 'LineWidth', 1.2);
title('Entropy của các khung', 'FontWeight', 'bold');
xlabel('Số thứ tự khung', 'FontWeight', 'bold');
ylabel('Entropy', 'FontWeight', 'bold');
grid on;
set(gca, 'FontSize', 10);

% 4. Phân tích biểu đồ phân phối
fprintf('\n4. PHÂN TÍCH BIỂU ĐỒ PHÂN PHỐI\n');

h5 = figure('Name', 'Phân tích biểu đồ phân phối', 'NumberTitle', 'off', 'Position', [300 300 900 400]);

% Tạo histogram của tín hiệu nghi ngờ
bins = 100;
[counts_stego, centers_stego] = hist(stego_data, bins);
counts_stego = counts_stego / sum(counts_stego); % Chuẩn hóa

if has_original
    % Tạo histogram của tín hiệu gốc
    [counts_orig, centers_orig] = hist(orig_data, bins);
    counts_orig = counts_orig / sum(counts_orig); % Chuẩn hóa
    
    % Hiển thị cả hai histogram
    bar(centers_stego, counts_stego, 'b');
    hold on;
    bar(centers_orig, counts_orig, 'g');
    hold off;
    legend('Tín hiệu nghi ngờ', 'Tín hiệu gốc');
    
    % Tính Kullback-Leibler divergence
    kl_div = 0;
    for i = 1:bins
        if counts_orig(i) > 0 && counts_stego(i) > 0
            kl_div = kl_div + counts_stego(i) * log2(counts_stego(i) / counts_orig(i));
        end
    end
    
    fprintf('Kullback-Leibler divergence: %.6f\n', kl_div);
else
    % Chỉ hiển thị histogram của tín hiệu nghi ngờ
    bar(centers_stego, counts_stego, 'b');
end

title('Biểu đồ phân phối biên độ', 'FontWeight', 'bold');
xlabel('Biên độ', 'FontWeight', 'bold');
ylabel('Tần suất chuẩn hóa', 'FontWeight', 'bold');
grid on;
set(gca, 'FontSize', 10);

% Kết luận dựa trên phân tích
fprintf('\n===== KẾT LUẬN PHÁT HIỆN =====\n');

% Tính điểm đánh giá tổng hợp
detection_score = 0;

% Nếu có các peak rõ rệt trong phân tích cepstrum
if ~isempty(peaks)
    fprintf('1. Phát hiện các đỉnh rõ rệt trong phân tích cepstrum, có thể là do hiệu ứng echo.\n');
    fprintf('2. Các vị trí echo tiềm năng: ');
    for i = 1:min(3, length(peaks))
        fprintf('%.2f ms', quefrency(peaks(i)));
        if i < min(3, length(peaks))
            fprintf(', ');
        end
    end
    if length(peaks) > 3
        fprintf(', ...');
    end
    fprintf('\n');
    
    % Tăng điểm phát hiện dựa trên số lượng đỉnh
    detection_score = detection_score + min(length(peaks), 5) * 10;
else
    fprintf('1. Không phát hiện các đỉnh rõ rệt trong phân tích cepstrum.\n');
    fprintf('2. Nếu Echo Hiding được sử dụng, echo có thể quá yếu để phát hiện bằng phương pháp này.\n');
end

% Nếu có file gốc để so sánh
if has_original
    fprintf('\n3. So sánh với file gốc cho thấy:\n');
    
    % Kiểm tra sự khác biệt thống kê
    if abs(stego_entropy - orig_entropy)/abs(orig_entropy) > 0.01
        fprintf('   - Có sự khác biệt đáng kể về entropy (%.2f%%)\n', 100*abs(stego_entropy - orig_entropy)/abs(orig_entropy));
        detection_score = detection_score + 10;
    end
    
    if abs(stego_kurtosis - orig_kurtosis)/abs(orig_kurtosis) > 0.05
        fprintf('   - Có sự khác biệt đáng kể về kurtosis (%.2f%%)\n', 100*abs(stego_kurtosis - orig_kurtosis)/abs(orig_kurtosis));
        detection_score = detection_score + 10;
    end
    
    % Kiểm tra sự khác biệt cepstrum
    if ~isempty(diff_peaks)
        fprintf('   - Phát hiện các đỉnh rõ rệt trong sự khác biệt cepstrum.\n');
        detection_score = detection_score + min(length(diff_peaks), 5) * 10;
    end
    
    % Đánh giá KL divergence
    if kl_div > 0.01
        fprintf('   - Kullback-Leibler divergence (%.6f) cho thấy có sự khác biệt trong phân phối.\n', kl_div);
        detection_score = detection_score + 10;
    end
end

% Đánh giá độ lệch chuẩn SNR giữa các khung
if snr_std > 5
    fprintf('\n4. Độ lệch chuẩn SNR giữa các khung (%.6f dB) tương đối cao, có thể do thay đổi giữa các khung khi nhúng thông tin.\n', snr_std);
    detection_score = detection_score + 10;
else
    fprintf('\n4. Độ lệch chuẩn SNR giữa các khung (%.6f dB) tương đối thấp.\n', snr_std);
end

% Đánh giá tổng thể
fprintf('\n===== ĐÁNH GIÁ TỔNG THỂ =====\n');
fprintf('Điểm phát hiện: %d/100\n', min(detection_score, 100));

if detection_score >= 70
    fprintf('KẾT LUẬN: Tệp âm thanh CHẮC CHẮN chứa thông tin giấu tin bằng phương pháp Echo Hiding.\n');
elseif detection_score >= 40
    fprintf('KẾT LUẬN: Tệp âm thanh CÓ KHẢ NĂNG chứa thông tin giấu tin bằng phương pháp Echo Hiding.\n');
elseif detection_score >= 20
    fprintf('KẾT LUẬN: Tệp âm thanh CÓ THỂ chứa thông tin giấu tin nhưng không chắc chắn.\n');
else
    fprintf('KẾT LUẬN: KHÔNG PHÁT HIỆN thông tin giấu tin trong tệp âm thanh hoặc phương pháp giấu tin quá tinh vi.\n');
end

% Giữ các figure mở cho đến khi người dùng nhấn phím
fprintf('\nNhấn một phím bất kỳ để đóng các cửa sổ đồ thị...\n');
pause;

% Hàm tự tương quan (xcorr) tự cài đặt
function [c, lags] = my_xcorr(x, maxlag, scale)
    % Tự cài đặt hàm xcorr cơ bản để thay thế cho hàm xcorr trong gói signal
    N = length(x);
    if nargin < 2 || isempty(maxlag)
        maxlag = N - 1;
    end
    maxlag = min(maxlag, N - 1);
    
    c = zeros(2*maxlag + 1, 1);
    lags = -maxlag:maxlag;
    
    for k = 1:2*maxlag+1
        lag = lags(k);
        if lag < 0
            c(k) = sum(x(1:N+lag) .* x(-lag+1:N));
        else
            c(k) = sum(x(lag+1:N) .* x(1:N-lag));
        end
    end
    
    % Chia tỷ lệ nếu được chỉ định
    if nargin >= 3 && strcmp(scale, 'coeff')
        c = c / c(maxlag + 1);
    end
end

