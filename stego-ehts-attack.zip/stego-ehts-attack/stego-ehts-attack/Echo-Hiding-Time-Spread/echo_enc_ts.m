function out = echo_enc_ts(signal, text, d0, d1, alpha, L)
%ECHO_ENC_MIRRORED Echo Hiding with mirrored echo kernels
%
%   INPUT VARIABLES
%       signal : Cover signal
%       text   : Message to hide
%       d0     : Delay rate for bit0
%       d1     : Delay rate for bit1
%       alpha  : Echo amplitude
%       L      : Length of frames
%
%   OUTPUT VARIABLES
%       out    : Stego signal
%
%   Kadir Tekeli (kadir.tekeli@outlook.com)

if nargin < 4
	d0 = 50;      %Delay rate for bit0 (khá nhỏ)
    d1 = 300;     %Delay rate for bit1 (khá lớn)
end

if nargin < 5
    alpha = 0.05;  %Echo amplitude (nhỏ như yêu cầu)
end

if nargin < 6
    L = 8*1024;   %Length of frames
end

[s.len, s.ch] = size(signal);

% Normalize signal
signal = signal / max(abs(signal(:)));

% Get binary representation of text
bit = getBits(text);

% Calculate number of available frames
nframe = floor(s.len/L);
N = nframe - mod(nframe,8);      %Number of frames (for 8 bit)

if (length(bit) > N)
    warning('Message is too long, being cropped!');
    bits = bit(1:N);
else
    warning('Message is being zero padded...');
    % Pad with zeros to fill available frames
    bits = [bit, num2str(zeros(N-length(bit), 1))'];
end

% Save parameters to a file for extraction
save_params(d0, d1, alpha, L, length(text));

% Simple embedding with repeated pattern for stronger detection
out = robust_embed(signal, bits, d0, d1, alpha, L, N, s.ch);

end

function out = robust_embed(signal, bits, d0, d1, alpha, L, N, nch)
% Robust echo embedding method with repeated patterns
out = signal;

% Tạo kernel cơ bản cho bit 0 và bit 1
k0 = zeros(L, 1);
k1 = zeros(L, 1);

% Đặt echo tại nhiều vị trí lặp lại để tăng cường phát hiện
echoes0 = [d0, 2*d0, 3*d0];  % Các vị trí echo cho bit 0
echoes1 = [d1, 2*d1, 3*d1];  % Các vị trí echo cho bit 1

% Đảm bảo các vị trí echo nằm trong giới hạn khung
valid_echoes0 = echoes0(echoes0 < L);
valid_echoes1 = echoes1(echoes1 < L);

% Tạo kernel với các echo lặp lại, giảm dần biên độ
for i = 1:length(valid_echoes0)
    k0(valid_echoes0(i)+1) = alpha * (0.9^(i-1));
end

for i = 1:length(valid_echoes1)
    k1(valid_echoes1(i)+1) = alpha * (0.9^(i-1));
end

% Nhúng vào từng khung
for i = 1:min(length(bits), N)
    % Get current frame
    start_idx = (i-1)*L + 1;
    end_idx = min(start_idx + L - 1, length(signal));
    frame_len = end_idx - start_idx + 1;
    
    if frame_len < L
        continue;  % Bỏ qua khung cuối nếu không đủ độ dài
    end
    
    % Tạo kernel dựa trên giá trị bit
    if bits(i) == '0'
        kernel = k0;
    else
        kernel = k1;
    end
    
    % Nhúng echo bằng phép tích chập (convolution)
    frame = signal(start_idx:end_idx, :);
    for ch = 1:size(frame, 2)
        echo_frame = conv(frame(:,ch), kernel, 'same');
        out(start_idx:end_idx, ch) = frame(:,ch) + echo_frame;
    end
end

% Normalize output to prevent clipping
out = 0.95 * out / max(abs(out(:)));
end

function save_params(d0, d1, alpha, L, len_msg)
% Save parameters to a file for later extraction
fid = fopen('stego_params.txt', 'w');
fprintf(fid, '%d\n', d0);
fprintf(fid, '%d\n', d1);
fprintf(fid, '%f\n', alpha);
fprintf(fid, '%d\n', L);
fprintf(fid, '%d\n', len_msg);
fclose(fid);
end