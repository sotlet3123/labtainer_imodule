close all; clear all; clc;

% Load stego audio
audio = audioload();

% Read original message
file = 'text.txt';
fid  = fopen(file, 'r');
text = fread(fid,'*char')';
fclose(fid);

% Đọc các tham số từ file đã lưu
param_file = 'stego_params.txt';
if exist(param_file, 'file')
    fid = fopen(param_file, 'r');
    d0 = str2num(fgetl(fid));
    d1 = str2num(fgetl(fid));
    alpha = str2num(fgetl(fid));
    L = str2num(fgetl(fid));
    len_msg = str2num(fgetl(fid));
    fclose(fid);
else
    % Nếu không có file tham số, sử dụng tham số mặc định
    d0 = 50;      % Delay cho bit 0
    d1 = 300;     % Delay cho bit 1
    alpha = 0.05; % Biên độ echo
    L = 8*1024;   % Kích thước khung
    len_msg = length(text);  % Độ dài tin nhắn gốc
end

% Thực hiện giải mã
msg = echo_dec_ts(audio.data, L, d0, d1, len_msg);

% Đánh giá kết quả
err = BER(text, msg);
nc = NC(text, msg);

% Hiển thị kết quả
fprintf('\n-------- KẾT QUẢ ĐÁNH GIÁ --------\n');
fprintf('Tin gốc     : %s\n', text);
fprintf('Tin trích xuất: %s\n', msg);
fprintf('BER         : %.2f%%\n', err);
fprintf('NC          : %.6f\n', nc);
fprintf('----------------------------------\n');