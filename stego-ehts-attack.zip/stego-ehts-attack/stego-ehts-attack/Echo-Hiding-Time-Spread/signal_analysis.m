% PHÂN TÍCH TÍN HIỆU ÂM THANH ĐÃ GIẤU TIN
close all; clear all; clc;

% Load signal package for xcorr function
pkg load signal;

% Hiển thị tiêu đề
fprintf('===== PHÂN TÍCH TÍN HIỆU ÂM THANH ĐÃ GIẤU TIN =====\n\n');

% Cho phép người dùng chọn file âm thanh từ thư mục audio_out
fprintf('Chọn file âm thanh đã giấu tin từ thư mục audio_out...\n');
[file_name, file_path] = uigetfile({'*.wav;*.mp3;*.flac;*.ogg;*.aac', 'Audio Files (*.wav, *.mp3, *.flac, *.ogg, *.aac)'}, 'Chọn file âm thanh đã giấu tin', 'audio_out/');

% Kiểm tra xem người dùng đã chọn file hay chưa
if isequal(file_name, 0)
    fprintf('Người dùng đã hủy việc chọn file.\n');
    return;
end

% Hiển thị thông tin file đã chọn
fprintf('\nĐã chọn file: %s\n', fullfile(file_path, file_name));

% Đọc dữ liệu âm thanh
fprintf('\nĐang đọc dữ liệu âm thanh...\n');
try
    [audio_data, fs] = audioread(fullfile(file_path, file_name));
    fprintf('Đã đọc dữ liệu âm thanh thành công. Tần số lấy mẫu: %d Hz\n', fs);
catch ME
    fprintf('Lỗi khi đọc file âm thanh: %s\n', ME.message);
    return;
end

% Chuyển đổi thành mono nếu là stereo
if size(audio_data, 2) > 1
    fprintf('Phát hiện tín hiệu stereo. Chuyển đổi thành mono để phân tích...\n');
    audio_data = mean(audio_data, 2);
end

% Chuẩn hóa dữ liệu
audio_data = audio_data / max(abs(audio_data));

% 1. Phân tích tín hiệu trong miền thời gian
fprintf('\n1. PHÂN TÍCH TRONG MIỀN THỜI GIAN\n');

% Tính toán thống kê cơ bản
audio_mean = mean(audio_data);
audio_std = std(audio_data);
audio_max = max(abs(audio_data));
audio_min = min(abs(audio_data));
audio_energy = sum(audio_data.^2);

fprintf('- Giá trị trung bình: %.6f\n', audio_mean);
fprintf('- Độ lệch chuẩn: %.6f\n', audio_std);
fprintf('- Giá trị tuyệt đối lớn nhất: %.6f\n', audio_max);
fprintf('- Giá trị tuyệt đối nhỏ nhất: %.6f\n', audio_min);
fprintf('- Năng lượng tín hiệu: %.6f\n', audio_energy);

% Hiển thị biểu đồ dạng sóng
h1 = figure('Name', 'Phân tích tín hiệu trong miền thời gian', 'NumberTitle', 'off', 'Position', [100 100 1000 600]);

% Chọn một đoạn ngắn để hiển thị chi tiết (5000 mẫu đầu tiên)
sample_length = min(5000, length(audio_data));
time = (0:sample_length-1) / fs;

subplot(2, 1, 1);
plot(time, audio_data(1:sample_length), 'b-', 'LineWidth', 1.2);
title('Dạng sóng tín hiệu (5000 mẫu đầu tiên)', 'FontWeight', 'bold');
xlabel('Thời gian (giây)', 'FontWeight', 'bold');
ylabel('Biên độ', 'FontWeight', 'bold');
grid on;
set(gca, 'FontSize', 10);

% Tự tương quan - có thể phát hiện echo
subplot(2, 1, 2);
max_lag = min(10000, length(audio_data) - 1);
[acf, lags] = xcorr(audio_data, max_lag, 'coeff');
acf = acf(max_lag+1:end);
lags = lags(max_lag+1:end);
plot(lags/fs*1000, acf, 'r-', 'LineWidth', 1.2);
title('Tự tương quan tín hiệu (để phát hiện echo)', 'FontWeight', 'bold');
xlabel('Độ trễ (ms)', 'FontWeight', 'bold');
ylabel('Hệ số tương quan', 'FontWeight', 'bold');
grid on;
set(gca, 'FontSize', 10);
xlim([0 50]); % Chỉ hiển thị 50ms đầu tiên

% 2. Phân tích tín hiệu trong miền tần số
fprintf('\n2. PHÂN TÍCH TRONG MIỀN TẦN SỐ\n');

% Tính toán FFT
nfft = 2^nextpow2(length(audio_data));
Y = fft(audio_data, nfft);
Y = Y(1:nfft/2+1);
f = fs/2 * linspace(0, 1, nfft/2+1);

% Hiển thị phổ tần số
h2 = figure('Name', 'Phân tích tín hiệu trong miền tần số', 'NumberTitle', 'off', 'Position', [150 150 1000 600]);

subplot(2, 1, 1);
plot(f, 20*log10(abs(Y)), 'b-', 'LineWidth', 1.2);
title('Phổ tần số', 'FontWeight', 'bold');
xlabel('Tần số (Hz)', 'FontWeight', 'bold');
ylabel('Biên độ (dB)', 'FontWeight', 'bold');
grid on;
set(gca, 'FontSize', 10);

% Phổ tần số trong dải 0-5000 Hz
subplot(2, 1, 2);
freq_limit = 5000;
freq_idx = find(f <= freq_limit, 1, 'last');
plot(f(1:freq_idx), 20*log10(abs(Y(1:freq_idx))), 'b-', 'LineWidth', 1.2);
title(sprintf('Phổ tần số - Dải thấp (0-%d Hz)', freq_limit), 'FontWeight', 'bold');
xlabel('Tần số (Hz)', 'FontWeight', 'bold');
ylabel('Biên độ (dB)', 'FontWeight', 'bold');
grid on;
set(gca, 'FontSize', 10);

% 3. Phân tích cepstrum - phương pháp tốt để phát hiện echo
fprintf('\n3. PHÂN TÍCH CEPSTRUM\n');

% Tính cepstrum
log_mag = log(abs(Y) + eps);
ceps = real(ifft(log_mag));

% Hiển thị cepstrum
h3 = figure('Name', 'Phân tích Cepstrum', 'NumberTitle', 'off', 'Position', [200 200 1000 600]);

% Giới hạn phân tích cepstrum cho quefrencies thấp (tương ứng với độ trễ echo)
ceps_limit = min(1000, length(ceps));
quefrency = (0:ceps_limit-1) / fs * 1000; % Chuyển đổi sang ms

subplot(2, 1, 1);
plot(quefrency, ceps(1:ceps_limit), 'g-', 'LineWidth', 1.2);
title('Cepstrum (phát hiện echo)', 'FontWeight', 'bold');
xlabel('Quefrency (ms)', 'FontWeight', 'bold');
ylabel('Biên độ', 'FontWeight', 'bold');
grid on;
set(gca, 'FontSize', 10);

% Phóng to vùng quan tâm (0-50ms) - vùng chứa thông tin echo
subplot(2, 1, 2);
zoom_limit = min(find(quefrency >= 50), length(quefrency));
plot(quefrency(1:zoom_limit), ceps(1:zoom_limit), 'g-', 'LineWidth', 1.2);
title('Cepstrum - Phóng to (0-50ms)', 'FontWeight', 'bold');
xlabel('Quefrency (ms)', 'FontWeight', 'bold');
ylabel('Biên độ', 'FontWeight', 'bold');
grid on;
set(gca, 'FontSize', 10);

% Phát hiện các peak trong cepstrum (có thể là echo)
min_distance = round(0.5 / (1/fs) * 1000); % Khoảng cách tối thiểu giữa các peak (0.5ms)
min_height = 0.1 * max(ceps(1:zoom_limit)); % Ngưỡng chiều cao tối thiểu

% Tìm các peak (phiên bản đơn giản không sử dụng Signal Processing Toolbox)
peaks = [];
peak_heights = [];
for i = 2:zoom_limit-1
    if ceps(i) > ceps(i-1) && ceps(i) > ceps(i+1) && ceps(i) > min_height
        % Kiểm tra xem peak này có đủ xa so với peak trước không
        if isempty(peaks) || (quefrency(i) - quefrency(peaks(end)) >= 0.5)
            peaks = [peaks, i];
            peak_heights = [peak_heights, ceps(i)];
        end
    end
end

% Báo cáo các peak tìm được (có thể là vị trí echo)
fprintf('Phát hiện các đỉnh có thể là echo:\n');
for i = 1:length(peaks)
    fprintf('- Đỉnh tại %.2f ms với biên độ %.6f\n', quefrency(peaks(i)), peak_heights(i));
end

% 4. Phân tích phổ Short-time Fourier Transform (STFT) nếu có gói signal
try
    fprintf('\n4. PHÂN TÍCH STFT\n');
    
    % Tham số cho STFT
    window_length = 1024;
    overlap = 512;
    nfft_spec = 1024;
    
    % Tính STFT bằng spectrogram
    window = hanning(window_length);
    [S, f_spec, t_spec] = spectrogram(audio_data, window, overlap, nfft_spec, fs);
    
    % Hiển thị spectrogram
    h4 = figure('Name', 'Phân tích STFT', 'NumberTitle', 'off', 'Position', [250 250 1000 600]);
    imagesc(t_spec, f_spec, 20*log10(abs(S)));
    axis xy;
    colorbar;
    title('Spectrogram của tín hiệu', 'FontWeight', 'bold');
    xlabel('Thời gian (giây)', 'FontWeight', 'bold');
    ylabel('Tần số (Hz)', 'FontWeight', 'bold');
    set(gca, 'FontSize', 10);
    colormap(jet);
catch
    fprintf('\nKhông thể thực hiện phân tích STFT. Vui lòng cài đặt gói signal.\n');
end

% Kết luận dựa trên phân tích
fprintf('\n===== KẾT LUẬN =====\n');
fprintf('Phân tích tín hiệu cho thấy:\n');

% Nếu có các peak rõ rệt trong phân tích cepstrum
if ~isempty(peaks)
    fprintf('1. Phát hiện các đỉnh rõ rệt trong phân tích cepstrum, có thể là do hiệu ứng echo.\n');
    fprintf('2. Các vị trí echo tiềm năng: ');
    for i = 1:min(3, length(peaks))
        fprintf('%.2f ms', quefrency(peaks(i)));
        if i < min(3, length(peaks))
            fprintf(', ');
        end
    end
    if length(peaks) > 3
        fprintf(', ...');
    end
    fprintf('\n');
    fprintf('3. Kỹ thuật Echo Hiding có thể đã được sử dụng với các độ trễ khác nhau để mã hóa bit.\n');
else
    fprintf('1. Không phát hiện các đỉnh rõ rệt trong phân tích cepstrum.\n');
    fprintf('2. Nếu Echo Hiding được sử dụng, echo có thể quá yếu để phát hiện bằng phương pháp này.\n');
end

% Đề xuất hành động tiếp theo
fprintf('\n===== ĐỀ XUẤT =====\n');
fprintf('1. Thử sử dụng độ trễ echo phát hiện được để trích xuất thông tin giấu tin.\n');
fprintf('2. Sử dụng kỹ thuật tấn công như lọc, nén, hoặc thêm nhiễu để đánh giá độ bền của phương pháp giấu tin.\n');

% Giữ các figure mở cho đến khi người dùng nhấn phím
fprintf('\nNhấn một phím bất kỳ để đóng các cửa sổ đồ thị...\n');
pause;

% Hàm Hanning tự cài đặt (để không phụ thuộc vào Signal Processing Toolbox)
function w = hanning(L)
    % Tạo cửa sổ Hamming độ dài L
    if L <= 0
        w = [];
        return;
    end
    n = (0:L-1)';
    w = 0.5 - 0.5*cos(2*pi*n/(L-1));
end

