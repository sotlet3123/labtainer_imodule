% ĐÁNH GIÁ BẢO MẬT THUẬT TOÁN GIẤU TIN ECHO HIDING
close all; clear all; clc;

% Kiểm tra và tải gói signal nếu có
has_signal_pkg = false;
try
    pkg('list');
    if exist('pkg') == 5 % function exists
        pkg_list = pkg('list');
        is_signal_installed = false;
        for i = 1:length(pkg_list)
            if strcmp(pkg_list{i}.name, 'signal')
                is_signal_installed = true;
                has_signal_pkg = true;
                if ~pkg_list{i}.loaded
                    pkg('load', 'signal');
                    fprintf('Đã tải gói signal.\n');
                end
                break;
            end
        end
        if ~is_signal_installed
            fprintf('Cảnh báo: Gói signal không được cài đặt. Sẽ sử dụng các hàm tự cài đặt.\n');
        end
    end
catch
    fprintf('Cảnh báo: Không thể kiểm tra/tải gói signal. Sẽ sử dụng các hàm tự cài đặt.\n');
end

% Hiển thị tiêu đề
fprintf('===== ĐÁNH GIÁ BẢO MẬT THUẬT TOÁN GIẤU TIN ECHO HIDING =====\n\n');
fprintf('Chương trình này thực hiện đánh giá độ an toàn của thuật toán giấu tin Echo Hiding\n');
fprintf('qua các phương pháp kiểm tra độ bền vững đối với các tấn công thông thường.\n\n');

% Cho phép người dùng chọn file âm thanh gốc
fprintf('Chọn file âm thanh gốc từ thư mục audio_in...\n');
[orig_name, orig_path] = uigetfile({'*.wav;*.mp3;*.flac;*.ogg;*.aac', 'Audio Files (*.wav, *.mp3, *.flac, *.ogg, *.aac)'}, 'Chọn file âm thanh gốc', 'audio_in/');

% Kiểm tra xem người dùng đã chọn file hay chưa
if isequal(orig_name, 0)
    fprintf('Người dùng đã hủy việc chọn file gốc.\n');
    return;
end

% Cho phép người dùng chọn file âm thanh đã giấu tin
fprintf('\nChọn file âm thanh đã giấu tin từ thư mục audio_out...\n');
[stego_name, stego_path] = uigetfile({'*.wav;*.mp3;*.flac;*.ogg;*.aac', 'Audio Files (*.wav, *.mp3, *.flac, *.ogg, *.aac)'}, 'Chọn file âm thanh đã giấu tin', 'audio_out/');

% Kiểm tra xem người dùng đã chọn file hay chưa
if isequal(stego_name, 0)
    fprintf('Người dùng đã hủy việc chọn file đã giấu tin.\n');
    return;
end

% Hiển thị thông tin file đã chọn
fprintf('\nĐã chọn các file:\n');
fprintf('- Âm thanh gốc: %s\n', fullfile(orig_path, orig_name));
fprintf('- Âm thanh đã giấu tin: %s\n', fullfile(stego_path, stego_name));

% Đọc dữ liệu âm thanh
fprintf('\nĐang đọc dữ liệu âm thanh...\n');

% Thử đọc file gốc với nhiều phương pháp
orig_data = [];
orig_fs = 0;
error_message = '';

try
    % Phương pháp 1: Sử dụng audioread (MATLAB/Octave mới)
    fprintf('Thử đọc file gốc bằng audioread...\n');
    [orig_data, orig_fs] = audioread(fullfile(orig_path, orig_name));
    fprintf('Đã đọc dữ liệu âm thanh gốc thành công. Tần số lấy mẫu: %d Hz\n', orig_fs);
catch ME1
    error_message = ME1.message;
    fprintf('Lỗi khi sử dụng audioread: %s\n', error_message);
    
    try
        % Phương pháp 2: Kiểm tra nếu có hàm wavread (Octave cũ)
        fprintf('Thử đọc file gốc bằng wavread...\n');
        if exist('wavread', 'file')
            [orig_data, orig_fs] = wavread(fullfile(orig_path, orig_name));
            fprintf('Đã đọc dữ liệu âm thanh gốc thành công. Tần số lấy mẫu: %d Hz\n', orig_fs);
        else
            fprintf('Hàm wavread không khả dụng.\n');
        end
    catch ME2
        error_message = [error_message, '\n', ME2.message];
        fprintf('Lỗi khi sử dụng wavread: %s\n', ME2.message);
        
        try
            % Phương pháp 3: Sử dụng hàm audioload tùy chỉnh nếu có
            fprintf('Thử đọc file gốc bằng hàm audioload tùy chỉnh...\n');
            if exist('audioload', 'file')
                [orig_data, orig_fs] = audioload(fullfile(orig_path, orig_name));
                fprintf('Đã đọc dữ liệu âm thanh gốc thành công. Tần số lấy mẫu: %d Hz\n', orig_fs);
            else
                fprintf('Hàm audioload không khả dụng.\n');
            end
        catch ME3
            error_message = [error_message, '\n', ME3.message];
            fprintf('Lỗi khi sử dụng audioload: %s\n', ME3.message);
        end
    end
end

% Kiểm tra xem đã đọc được dữ liệu gốc chưa
if isempty(orig_data) || orig_fs == 0
    fprintf('\nKhông thể đọc file âm thanh gốc: %s\n', error_message);
    fprintf('Vui lòng kiểm tra file có tồn tại và đúng định dạng không.\n');
    fprintf('Thử lại với tệp khác hoặc tiếp tục chỉ với file stego.\n');
    has_original = false;
    
    % Hỏi người dùng có muốn tiếp tục chỉ với file stego hay không
    choice = input('\nBạn có muốn tiếp tục chỉ với file stego không? (y/n): ', 's');
    if ~strcmpi(choice, 'y')
        fprintf('Đã hủy đánh giá.\n');
        return;
    end
else
    has_original = true;
end

% Thử đọc file stego với nhiều phương pháp
stego_data = [];
stego_fs = 0;
error_message = '';

try
    % Phương pháp 1: Sử dụng audioread (MATLAB/Octave mới)
    fprintf('Thử đọc file stego bằng audioread...\n');
    [stego_data, stego_fs] = audioread(fullfile(stego_path, stego_name));
    fprintf('Đã đọc dữ liệu âm thanh stego thành công. Tần số lấy mẫu: %d Hz\n', stego_fs);
catch ME1
    error_message = ME1.message;
    fprintf('Lỗi khi sử dụng audioread: %s\n', error_message);
    
    try
        % Phương pháp 2: Kiểm tra nếu có hàm wavread (Octave cũ)
        fprintf('Thử đọc file stego bằng wavread...\n');
        if exist('wavread', 'file')
            [stego_data, stego_fs] = wavread(fullfile(stego_path, stego_name));
            fprintf('Đã đọc dữ liệu âm thanh stego thành công. Tần số lấy mẫu: %d Hz\n', stego_fs);
        else
            fprintf('Hàm wavread không khả dụng.\n');
        end
    catch ME2
        error_message = [error_message, '\n', ME2.message];
        fprintf('Lỗi khi sử dụng wavread: %s\n', ME2.message);
        
        try
            % Phương pháp 3: Sử dụng hàm audioload tùy chỉnh nếu có
            fprintf('Thử đọc file stego bằng hàm audioload tùy chỉnh...\n');
            if exist('audioload', 'file')
                [stego_data, stego_fs] = audioload(fullfile(stego_path, stego_name));
                fprintf('Đã đọc dữ liệu âm thanh stego thành công. Tần số lấy mẫu: %d Hz\n', stego_fs);
            else
                fprintf('Hàm audioload không khả dụng.\n');
            end
        catch ME3
            error_message = [error_message, '\n', ME3.message];
            fprintf('Lỗi khi sử dụng audioload: %s\n', ME3.message);
        end
    end
end

% Kiểm tra xem đã đọc được dữ liệu stego chưa
if isempty(stego_data) || stego_fs == 0
    fprintf('\nKhông thể đọc file âm thanh stego: %s\n', error_message);
    fprintf('Vui lòng kiểm tra file có tồn tại và đúng định dạng không.\n');
    fprintf('Không thể tiếp tục đánh giá.\n');
    return;
end

% Nếu có cả hai file, đảm bảo tần số lấy mẫu phù hợp
if has_original
    if orig_fs ~= stego_fs
        fprintf('Cảnh báo: Hai file có tần số lấy mẫu khác nhau (%d Hz và %d Hz).\n', orig_fs, stego_fs);
        fprintf('Đang chuyển đổi file stego để phù hợp với tần số lấy mẫu của file gốc...\n');
        stego_data = resample(stego_data, orig_fs, stego_fs);
        stego_fs = orig_fs;
    end
    
    fs = orig_fs;
else
    fs = stego_fs;
end

fprintf('Tần số lấy mẫu cuối cùng: %d Hz\n', fs);

% Đảm bảo cả hai tín hiệu có cùng độ dài
if has_original
    min_length = min(size(orig_data, 1), size(stego_data, 1));
    orig_data = orig_data(1:min_length, :);
    stego_data = stego_data(1:min_length, :);
end

% Nếu là stereo, chuyển sang mono để phân tích
if size(stego_data, 2) > 1
    stego_mono = mean(stego_data, 2);
    fprintf('Phát hiện tín hiệu stereo. Chuyển đổi thành mono để phân tích...\n');
else
    stego_mono = stego_data;
end

if has_original
    if size(orig_data, 2) > 1
        orig_mono = mean(orig_data, 2);
    else
        orig_mono = orig_data;
    end
end

% Chuẩn hóa dữ liệu
stego_mono = stego_mono / max(abs(stego_mono));
if has_original
    orig_mono = orig_mono / max(abs(orig_mono));
end

fprintf('\n===== ĐÁNH GIÁ CƠ BẢN =====\n');

% 1. Tính các thông số chất lượng âm thanh
fprintf('\n1. ĐÁNH GIÁ CHẤT LƯỢNG ÂM THANH\n');

if has_original
    % SNR (Signal-to-Noise Ratio)
    signal_power = sum(orig_mono.^2);
    noise = stego_mono - orig_mono;
    noise_power = sum(noise.^2);
    snr_val = 10 * log10(signal_power / noise_power);
    fprintf('- SNR (Signal-to-Noise Ratio): %.2f dB\n', snr_val);

    % PSNR (Peak Signal-to-Noise Ratio)
    max_val = max(abs(orig_mono));
    mse_val = mean((orig_mono - stego_mono).^2);
    psnr_val = 10 * log10(max_val^2 / mse_val);
    fprintf('- PSNR (Peak Signal-to-Noise Ratio): %.2f dB\n', psnr_val);

    % NC (Normalized Correlation)
    nc_val = sum(orig_mono .* stego_mono) / sqrt(sum(orig_mono.^2) * sum(stego_mono.^2));
    fprintf('- NC (Normalized Correlation): %.6f\n', nc_val);
else
    % Nếu không có file gốc, thực hiện phân tích trên file stego
    fprintf('- Không có file gốc để so sánh. Thực hiện phân tích trên file stego.\n');
    
    % Phân tích phổ tần số
    nfft = 2^nextpow2(length(stego_mono));
    stego_fft = fft(stego_mono, nfft);
    stego_mag = abs(stego_fft(1:nfft/2+1));
    freq = fs/2 * linspace(0, 1, nfft/2+1);
    
    % Tính các thông số thống kê
    stego_mean = mean(stego_mono);
    stego_std = std(stego_mono);
    stego_energy = sum(stego_mono.^2);
    
    fprintf('- Giá trị trung bình: %.6f\n', stego_mean);
    fprintf('- Độ lệch chuẩn: %.6f\n', stego_std);
    fprintf('- Năng lượng tín hiệu: %.6f\n', stego_energy);
    
    % Hiển thị phổ tần số
    h1 = figure('Name', 'Phân tích phổ tần số', 'NumberTitle', 'off', 'Position', [100 100 900 500]);
    plot(freq, 20*log10(stego_mag+eps), 'b-', 'LineWidth', 1.2);
    title('Phổ tần số của tín hiệu stego', 'FontWeight', 'bold');
    xlabel('Tần số (Hz)', 'FontWeight', 'bold');
    ylabel('Biên độ (dB)', 'FontWeight', 'bold');
    grid on;
    set(gca, 'FontSize', 10);
end

% Đọc tin nhắn gốc từ file
try
    file = 'text.txt';
    fid  = fopen(file, 'r');
    orig_msg = fread(fid, '*char')';
    fclose(fid);
    have_orig_msg = true;
    fprintf('- Đã đọc tin nhắn gốc (%d ký tự): %s\n', length(orig_msg), orig_msg);
catch
    have_orig_msg = false;
    fprintf('- Không thể đọc tin nhắn gốc từ file text.txt\n');
end

% Phân tích cepstrum nếu chỉ có file stego
if ~has_original
    fprintf('\n2. PHÂN TÍCH CEPSTRUM ĐỂ PHÁT HIỆN ECHO\n');
    
    % Tính cepstrum để phát hiện độ trễ echo
    nfft = 2^nextpow2(length(stego_mono));
    stego_fft = fft(stego_mono, nfft);
    stego_log_spectrum = log(abs(stego_fft(1:nfft/2+1)) + eps);
    stego_cepstrum = real(ifft(stego_log_spectrum));
    
    % Lọc cepstrum để làm nổi bật các đỉnh - Implementastion inline
    % (Làm mịn tín hiệu bằng cách lấy trung bình cửa sổ trượt)
    span = 5;
    half_span = floor(span/2);
    stego_cepstrum_smooth = zeros(size(stego_cepstrum));
    
    for i = 1:length(stego_cepstrum)
        start_idx = max(1, i-half_span);
        end_idx = min(length(stego_cepstrum), i+half_span);
        stego_cepstrum_smooth(i) = mean(stego_cepstrum(start_idx:end_idx));
    end
    
    % Giới hạn phân tích cepstrum cho quefrencies thấp
    ceps_limit = min(1000, length(stego_cepstrum_smooth));
    quefrency = (0:ceps_limit-1) / fs * 1000; % Chuyển đổi sang ms
    
    % Tìm các peak trong cepstrum để xác định độ trễ echo
    zoom_limit = min(find(quefrency >= 50), length(quefrency));
    min_height = 0.05 * max(stego_cepstrum_smooth(1:zoom_limit));
    
    % Tìm các peak
    peaks = [];
    peak_heights = [];
    for i = 3:zoom_limit-3
        % Thêm điều kiện để tìm peak tốt hơn
        local_max = true;
        for j = -2:2
            if j != 0 && stego_cepstrum_smooth(i) <= stego_cepstrum_smooth(i+j)
                local_max = false;
                break;
            end
        end
        
        if local_max && stego_cepstrum_smooth(i) > min_height
            if isempty(peaks) || (quefrency(i) - quefrency(peaks(end)) >= 0.5)
                peaks = [peaks, i];
                peak_heights = [peak_heights, stego_cepstrum_smooth(i)];
            end
        end
    end
    
    % Hiển thị biểu đồ cepstrum với các peak
    h2 = figure('Name', 'Phân tích Cepstrum để phát hiện độ trễ Echo', 'NumberTitle', 'off', 'Position', [150 150 900 400]);
    plot(quefrency(1:zoom_limit), stego_cepstrum_smooth(1:zoom_limit), 'b-', 'LineWidth', 1.2);
    hold on;
    
    % Đánh dấu các peak tìm được
    if ~isempty(peaks)
        for i = 1:length(peaks)
            if peaks(i) <= zoom_limit
                plot(quefrency(peaks(i)), stego_cepstrum_smooth(peaks(i)), 'ro', 'MarkerSize', 8, 'LineWidth', 1.5);
                text(quefrency(peaks(i)), stego_cepstrum_smooth(peaks(i))*1.1, sprintf('%.2f ms', quefrency(peaks(i))), 'FontSize', 8);
            end
        end
    end
    hold off;
    title('Cepstrum phát hiện Echo (0-50 ms)', 'FontWeight', 'bold');
    xlabel('Quefrency (ms)', 'FontWeight', 'bold');
    ylabel('Biên độ', 'FontWeight', 'bold');
    grid on;
    set(gca, 'FontSize', 10);
    
    % Báo cáo các peak tìm được
    if ~isempty(peaks)
        fprintf('\nĐã phát hiện các đỉnh cepstrum có thể là echo:\n');
        for i = 1:min(5, length(peaks))
            fprintf('- Đỉnh tại %.2f ms\n', quefrency(peaks(i)));
        end
        
        % Ước lượng các tham số echo
        [sorted_heights, idx] = sort(peak_heights, 'descend');
        sorted_peaks = peaks(idx);
        
        if length(sorted_peaks) >= 2
            fprintf('\nCác tham số ước lượng cho Echo Hiding:\n');
            fprintf('- Độ trễ bit 0 (d0): khoảng %.2f ms\n', quefrency(sorted_peaks(1)));
            fprintf('- Độ trễ bit 1 (d1): khoảng %.2f ms\n', quefrency(sorted_peaks(2)));
        end
    else
        fprintf('\nKhông phát hiện các đỉnh cepstrum rõ rệt.\n');
    end
end

fprintf('\n===== ĐÁNH GIÁ ĐỘ BỀN VỮNG =====\n');

% 2. Tạo thư mục để lưu các file tấn công
if ~exist('attacked_audio', 'dir')
    mkdir('attacked_audio');
end

% 3. Thực hiện các loại tấn công và đánh giá
fprintf('\n3. TẤN CÔNG NÉN TÍN HIỆU\n');

% Tạo tên file cho tệp tấn công
[~, name, ~] = fileparts(stego_name);
attack_mp3_file = fullfile('attacked_audio', [name, '_mp3_64k.mp3']);

% Nén MP3 bitrate thấp
fprintf('- Tấn công nén MP3 64 kbps...\n');
try
    % Lưu thành file tạm thời
    tmp_wav = fullfile('attacked_audio', 'tmp_stego.wav');
    audiowrite(tmp_wav, stego_data, fs);
    
    % Tạo lệnh nén MP3 với LAME (giả định LAME đã được cài đặt)
    mp3_cmd = sprintf('lame --quiet -h -b 64 "%s" "%s"', tmp_wav, attack_mp3_file);
    [status, ~] = system(mp3_cmd);
    
    if status == 0
        fprintf('  Đã tạo file nén MP3: %s\n', attack_mp3_file);
    else
        fprintf('  Lỗi khi chạy lệnh nén MP3. Đảm bảo LAME encoder đã được cài đặt.\n');
    end
    
    % Đọc lại file MP3 đã nén
    [attack_mp3_data, attack_fs] = audioread(attack_mp3_file);
    if attack_fs ~= fs
        attack_mp3_data = resample(attack_mp3_data, fs, attack_fs);
    end
    
    % Đảm bảo cùng độ dài với tín hiệu gốc
    min_length = min(size(orig_data, 1), size(attack_mp3_data, 1));
    attack_mp3_mono = mean(attack_mp3_data(1:min_length, :), 2);
    attack_mp3_mono = attack_mp3_mono / max(abs(attack_mp3_mono));
    
    % Đánh giá chất lượng sau khi nén
    mp3_snr = 10 * log10(sum(stego_mono(1:min_length).^2) / sum((stego_mono(1:min_length) - attack_mp3_mono).^2));
    mp3_nc = sum(stego_mono(1:min_length) .* attack_mp3_mono) / sqrt(sum(stego_mono(1:min_length).^2) * sum(attack_mp3_mono.^2));
    
    fprintf('  - SNR sau khi nén MP3: %.2f dB\n', mp3_snr);
    fprintf('  - NC sau khi nén MP3: %.6f\n', mp3_nc);
    
    % Xóa file tạm thời
    delete(tmp_wav);
catch ME
    fprintf('  Lỗi khi thực hiện tấn công nén MP3: %s\n', ME.message);
end

% Phân tích cepstrum để phát hiện echo
if ~has_original
    fprintf('\n2. PHÂN TÍCH CEPSTRUM ĐỂ PHÁT HIỆN ECHO\n');
    
    % Tính cepstrum để phát hiện độ trễ echo
    nfft = 2^nextpow2(length(stego_mono));
    stego_fft = fft(stego_mono, nfft);
    stego_log_spectrum = log(abs(stego_fft(1:nfft/2+1)) + eps);
    stego_cepstrum = real(ifft(stego_log_spectrum));
    
    % Lọc cepstrum để làm nổi bật các đỉnh - Implementastion inline
    % (Làm mịn tín hiệu bằng cách lấy trung bình cửa sổ trượt)
    span = 5;
    half_span = floor(span/2);
    stego_cepstrum_smooth = zeros(size(stego_cepstrum));
    
    for i = 1:length(stego_cepstrum)
        start_idx = max(1, i-half_span);
        end_idx = min(length(stego_cepstrum), i+half_span);
        stego_cepstrum_smooth(i) = mean(stego_cepstrum(start_idx:end_idx));
    end
    
    % Giới hạn phân tích cepstrum cho quefrencies thấp
    ceps_limit = min(1000, length(stego_cepstrum_smooth));
    quefrency = (0:ceps_limit-1) / fs * 1000; % Chuyển đổi sang ms
    
    % Tìm các peak trong cepstrum để xác định độ trễ echo
    zoom_limit = min(find(quefrency >= 50), length(quefrency));
    min_height = 0.05 * max(stego_cepstrum_smooth(1:zoom_limit));
    
    % Tìm các peak
    peaks = [];
    peak_heights = [];
    for i = 3:zoom_limit-3
        % Thêm điều kiện để tìm peak tốt hơn
        local_max = true;
        for j = -2:2
            if j != 0 && stego_cepstrum_smooth(i) <= stego_cepstrum_smooth(i+j)
                local_max = false;
                break;
            end
        end
        
        if local_max && stego_cepstrum_smooth(i) > min_height
            if isempty(peaks) || (quefrency(i) - quefrency(peaks(end)) >= 0.5)
                peaks = [peaks, i];
                peak_heights = [peak_heights, stego_cepstrum_smooth(i)];
            end
        end
    end
    
    % Hiển thị biểu đồ cepstrum với các peak
    h2 = figure('Name', 'Phân tích Cepstrum để phát hiện độ trễ Echo', 'NumberTitle', 'off', 'Position', [150 150 900 400]);
    plot(quefrency(1:zoom_limit), stego_cepstrum_smooth(1:zoom_limit), 'b-', 'LineWidth', 1.2);
    hold on;
    
    % Đánh dấu các peak tìm được
    if ~isempty(peaks)
        for i = 1:length(peaks)
            if peaks(i) <= zoom_limit
                plot(quefrency(peaks(i)), stego_cepstrum_smooth(peaks(i)), 'ro', 'MarkerSize', 8, 'LineWidth', 1.5);
                text(quefrency(peaks(i)), stego_cepstrum_smooth(peaks(i))*1.1, sprintf('%.2f ms', quefrency(peaks(i))), 'FontSize', 8);
            end
        end
    end
    hold off;
    title('Cepstrum phát hiện Echo (0-50 ms)', 'FontWeight', 'bold');
    xlabel('Quefrency (ms)', 'FontWeight', 'bold');
    ylabel('Biên độ', 'FontWeight', 'bold');
    grid on;
    set(gca, 'FontSize', 10);
    
    % Báo cáo các peak tìm được
    if ~isempty(peaks)
        fprintf('\nĐã phát hiện các đỉnh cepstrum có thể là echo:\n');
        for i = 1:min(5, length(peaks))
            fprintf('- Đỉnh tại %.2f ms\n', quefrency(peaks(i)));
        end
        
        % Ước lượng các tham số echo
        [sorted_heights, idx] = sort(peak_heights, 'descend');
        sorted_peaks = peaks(idx);
        
        if length(sorted_peaks) >= 2
            fprintf('\nCác tham số ước lượng cho Echo Hiding:\n');
            fprintf('- Độ trễ bit 0 (d0): khoảng %.2f ms\n', quefrency(sorted_peaks(1)));
            fprintf('- Độ trễ bit 1 (d1): khoảng %.2f ms\n', quefrency(sorted_peaks(2)));
        end
    else
        fprintf('\nKhông phát hiện các đỉnh cepstrum rõ rệt.\n');
    end
end

fprintf('\n4. TẤN CÔNG THÊM NHIỄU\n');

% Thêm nhiễu Gaussian
fprintf('- Tấn công thêm nhiễu Gaussian (SNR = 20dB)...\n');

% Tạo nhiễu Gaussian với SNR = 20dB
target_snr_db = 20;
stego_power = sum(stego_mono.^2) / length(stego_mono);
noise_power_target = stego_power / (10^(target_snr_db/10));
noise_std = sqrt(noise_power_target);
noise_gaussian = noise_std * randn(size(stego_mono));

% Thêm nhiễu vào tín hiệu
stego_noisy = stego_mono + noise_gaussian;
stego_noisy = stego_noisy / max(abs(stego_noisy)); % Chuẩn hóa lại

% Lưu tệp nhiễu
attack_noise_file = fullfile('attacked_audio', [name, '_noisy_20dB.wav']);
audiowrite(attack_noise_file, stego_noisy, fs);
fprintf('  Đã tạo file với nhiễu: %s\n', attack_noise_file);

% Đánh giá chất lượng sau khi thêm nhiễu
noise_snr = 10 * log10(sum(stego_mono.^2) / sum((stego_mono - stego_noisy).^2));
noise_nc = sum(stego_mono .* stego_noisy) / sqrt(sum(stego_mono.^2) * sum(stego_noisy.^2));

fprintf('  - SNR sau khi thêm nhiễu: %.2f dB\n', noise_snr);
fprintf('  - NC sau khi thêm nhiễu: %.6f\n', noise_nc);

fprintf('\n5. TẤN CÔNG CẮT GHÉP\n');

% Cắt một phần và ghép lại
fprintf('- Tấn công cắt một phần và ghép lại...\n');
segment_len = floor(length(stego_mono) / 5); % Chia thành 5 phần
stego_cutpaste = stego_mono;
stego_cutpaste(segment_len+1:2*segment_len) = stego_mono(2*segment_len+1:3*segment_len);
stego_cutpaste(2*segment_len+1:3*segment_len) = stego_mono(segment_len+1:2*segment_len);

% Lưu tệp đã cắt ghép
attack_cutpaste_file = fullfile('attacked_audio', [name, '_cutpaste.wav']);
audiowrite(attack_cutpaste_file, stego_cutpaste, fs);
fprintf('  Đã tạo file cắt ghép: %s\n', attack_cutpaste_file);

% Đánh giá chất lượng sau khi cắt ghép
cutpaste_snr = 10 * log10(sum(stego_mono.^2) / sum((stego_mono - stego_cutpaste).^2));
cutpaste_nc = sum(stego_mono .* stego_cutpaste) / sqrt(sum(stego_mono.^2) * sum(stego_cutpaste.^2));

fprintf('  - SNR sau khi cắt ghép: %.2f dB\n', cutpaste_snr);
fprintf('  - NC sau khi cắt ghép: %.6f\n', cutpaste_nc);

fprintf('\n6. TẤN CÔNG LỌC\n');

% Lọc thông thấp
fprintf('- Tấn công lọc thông thấp (cutoff = 4kHz)...\n');
cutoff_freq = 4000; % 4kHz
[b, a] = butter(6, cutoff_freq/(fs/2), 'low');
stego_lowpass = filter(b, a, stego_mono);
stego_lowpass = stego_lowpass / max(abs(stego_lowpass)); % Chuẩn hóa lại

% Lưu tệp đã lọc
attack_lowpass_file = fullfile('attacked_audio', [name, '_lowpass_4kHz.wav']);
audiowrite(attack_lowpass_file, stego_lowpass, fs);
fprintf('  Đã tạo file lọc thông thấp: %s\n', attack_lowpass_file);

% Đánh giá chất lượng sau khi lọc
lowpass_snr = 10 * log10(sum(stego_mono.^2) / sum((stego_mono - stego_lowpass).^2));
lowpass_nc = sum(stego_mono .* stego_lowpass) / sqrt(sum(stego_mono.^2) * sum(stego_lowpass.^2));

fprintf('  - SNR sau khi lọc thông thấp: %.2f dB\n', lowpass_snr);
fprintf('  - NC sau khi lọc thông thấp: %.6f\n', lowpass_nc);

% Tạo bảng tổng hợp kết quả
fprintf('\n===== BẢNG TỔNG HỢP KẾT QUẢ ĐÁNH GIÁ =====\n\n');

if has_original
    fprintf('| %-20s | %-10s | %-10s |\n', 'Loại tấn công', 'SNR (dB)', 'NC');
    fprintf('|----------------------|------------|------------|\n');
    fprintf('| %-20s | %-10.2f | %-10.6f |\n', 'Không tấn công', snr_val, nc_val);
    fprintf('| %-20s | %-10.2f | %-10.6f |\n', 'Nén MP3 64kbps', mp3_snr, mp3_nc);
    fprintf('| %-20s | %-10.2f | %-10.6f |\n', 'Thêm nhiễu Gaussian', noise_snr, noise_nc);
    fprintf('| %-20s | %-10.2f | %-10.6f |\n', 'Cắt ghép', cutpaste_snr, cutpaste_nc);
    fprintf('| %-20s | %-10.2f | %-10.6f |\n', 'Lọc thông thấp', lowpass_snr, lowpass_nc);
else
    fprintf('Không thể tạo bảng tổng hợp kết quả do không có file gốc để so sánh.\n');
end

% Kiểm tra khả năng trích xuất tin nhắn sau tấn công
if has_original
    fprintf('\n===== KIỂM TRA KHẢ NĂNG TRÍCH XUẤT SAU TẤN CÔNG =====\n');

    % Tìm kiếm tệp thông số giấu tin
    param_file = 'stego_params.txt';
    if exist(param_file, 'file')
        fprintf('\nĐọc các tham số từ file %s...\n', param_file);
        fid = fopen(param_file, 'r');
        d0 = str2num(fgetl(fid));
        d1 = str2num(fgetl(fid));
        alpha = str2num(fgetl(fid));
        L = str2num(fgetl(fid));
        len_msg = str2num(fgetl(fid));
        fclose(fid);
        
        fprintf('Đã tìm thấy tham số giấu tin:\n');
        fprintf('- Độ trễ bit 0 (d0): %d\n', d0);
        fprintf('- Độ trễ bit 1 (d1): %d\n', d1);
        fprintf('- Hệ số biên độ (alpha): %.4f\n', alpha);
        fprintf('- Độ dài khung (L): %d\n', L);
        
        % Thực hiện đánh giá trích xuất thông tin
        % (rest of the extraction evaluation code...)
    else
        fprintf('\nKhông tìm thấy file tham số giấu tin, không thể kiểm tra khả năng trích xuất.\n');
    end
end

% Kết luận
fprintf('\n===== KẾT LUẬN ĐÁNH GIÁ BẢO MẬT =====\n');

if has_original
    fprintf('1. Chất lượng âm thanh sau khi giấu tin:\n');
    if snr_val > 40
        fprintf('   - Rất tốt (SNR > 40dB)\n');
    elseif snr_val > 30
        fprintf('   - Tốt (SNR > 30dB)\n');
    elseif snr_val > 20
        fprintf('   - Chấp nhận được (SNR > 20dB)\n');
    else
        fprintf('   - Kém (SNR < 20dB)\n');
    end

    fprintf('\n2. Độ bền vững đối với các loại tấn công:\n');

    % Đánh giá tấn công nén MP3
    if mp3_snr > 15 && mp3_nc > 0.9
        fprintf('   - Nén MP3: KHÁ BỀN VỮNG\n');
    else
        fprintf('   - Nén MP3: KHÔNG BỀN VỮNG\n');
    end

    % Đánh giá tấn công thêm nhiễu
    if noise_snr > 15 && noise_nc > 0.9
        fprintf('   - Thêm nhiễu: KHÁ BỀN VỮNG\n');
    else
        fprintf('   - Thêm nhiễu: KHÔNG BỀN VỮNG\n');
    end

    % Đánh giá tấn công cắt ghép
    if cutpaste_snr > 15 && cutpaste_nc > 0.9
        fprintf('   - Cắt ghép: KHÁ BỀN VỮNG\n');
    else
        fprintf('   - Cắt ghép: KHÔNG BỀN VỮNG\n');
    end

    % Đánh giá tấn công lọc
    if lowpass_snr > 15 && lowpass_nc > 0.9
        fprintf('   - Lọc thông thấp: KHÁ BỀN VỮNG\n');
    else
        fprintf('   - Lọc thông thấp: KHÔNG BỀN VỮNG\n');
    end

    fprintf('\n3. Khả năng trích xuất thông tin sau tấn công:\n');
    if exist('param_file', 'var') && have_orig_msg
        % Tính tổng hợp BER
        ber_ratings = [];
        
        if exist('orig_ber', 'var')
            ber_ratings = [ber_ratings, orig_ber];
        end
        
        if exist('mp3_ber', 'var')
            ber_ratings = [ber_ratings, mp3_ber];
        end
        
        if exist('noise_ber', 'var')
            ber_ratings = [ber_ratings, noise_ber];
        end
        
        if exist('cutpaste_ber', 'var')
            ber_ratings = [ber_ratings, cutpaste_ber];
        end
        
        if exist('lowpass_ber', 'var')
            ber_ratings = [ber_ratings, lowpass_ber];
        end
        
        % Đánh giá tổng thể
        avg_ber = mean(ber_ratings);
        if avg_ber < 10
            fprintf('   - Rất tốt: Phần lớn thông tin được trích xuất thành công sau tấn công (BER < 10%%)\n');
        elseif avg_ber < 30
            fprintf('   - Tốt: Một phần thông tin có thể được trích xuất sau tấn công (BER < 30%%)\n');
        elseif avg_ber < 50
            fprintf('   - Trung bình: Thông tin bị hư hại nhiều sau tấn công (BER < 50%%)\n');
        else
            fprintf('   - Kém: Thông tin bị mất hầu hết sau tấn công (BER > 50%%)\n');
        end
    else
        fprintf('   - Không thể đánh giá do thiếu thông tin tham số hoặc tin nhắn gốc.\n');
    end

    fprintf('\n4. Đánh giá khả năng phát hiện:\n');
    if snr_val > 50
        fprintf('   - Rất khó phát hiện (SNR > 50dB, gần như không có sự khác biệt với file gốc)\n');
    elseif snr_val > 35
        fprintf('   - Khó phát hiện (SNR > 35dB, sự khác biệt rất nhỏ)\n');
    elseif snr_val > 25
        fprintf('   - Có thể phát hiện với các công cụ chuyên dụng (SNR > 25dB)\n');
    else
        fprintf('   - Dễ phát hiện (SNR < 25dB, sự khác biệt đáng kể)\n');
    end

    fprintf('\n5. Kết luận tổng thể:\n');
    if snr_val > 30 && (exist('avg_ber', 'var') && avg_ber < 30)
        fprintf('   - Thuật toán Echo Hiding có hiệu quả tốt, cân bằng giữa độ khó phát hiện và độ bền vững.\n');
        fprintf('   - Phù hợp cho các ứng dụng giấu tin cần độ an toàn trung bình.\n');
    elseif snr_val > 40
        fprintf('   - Thuật toán Echo Hiding có độ khó phát hiện cao, nhưng độ bền vững chưa tốt.\n');
        fprintf('   - Phù hợp cho các ứng dụng giấu tin không yêu cầu độ bền vững cao.\n');
    elseif exist('avg_ber', 'var') && avg_ber < 20
        fprintf('   - Thuật toán Echo Hiding có độ bền vững tốt, nhưng có thể dễ bị phát hiện.\n');
        fprintf('   - Phù hợp cho các ứng dụng yêu cầu độ bền vững hơn là độ khó phát hiện.\n');
    else
        fprintf('   - Thuật toán Echo Hiding có hiệu quả trung bình.\n');
        fprintf('   - Cần cải thiện để cân bằng tốt hơn giữa độ khó phát hiện và độ bền vững.\n');
    end
else
    % Kết luận cho trường hợp chỉ có file stego
    fprintf('1. Phân tích tệp có giấu tin:\n');
    
    if exist('peaks', 'var') && ~isempty(peaks)
        fprintf('   - Phát hiện có các đỉnh trong phân tích cepstrum, có thể là do echo.\n');
        fprintf('   - Các độ trễ phát hiện được: ');
        for i = 1:min(3, length(peaks))
            fprintf('%.2f ms', quefrency(peaks(i)));
            if i < min(3, length(peaks))
                fprintf(', ');
            end
        end
        fprintf('\n');
        fprintf('   - Phương pháp Echo Hiding có khả năng đã được sử dụng.\n');
    else
        fprintf('   - Không phát hiện các đỉnh rõ rệt trong phân tích cepstrum.\n');
        fprintf('   - Không thể kết luận có sử dụng Echo Hiding hay không.\n');
    end
    
    fprintf('\n2. Các tấn công chất lượng tín hiệu:\n');
    fprintf('   - Đã thực hiện các tấn công nén, thêm nhiễu, cắt ghép và lọc.\n');
    fprintf('   - Không thể đánh giá mức độ ảnh hưởng đến chất lượng do không có tệp gốc.\n');
    
    fprintf('\n3. Đề xuất:\n');
    fprintf('   - Thử nghiệm với tệp gốc để có đánh giá chính xác hơn.\n');
    
    if exist('peaks', 'var') && ~isempty(peaks)
        fprintf('   - Sử dụng các tham số ước lượng từ phân tích cepstrum để trích xuất thông tin.\n');
        if length(peaks) >= 2
            [sorted_heights, idx] = sort(peak_heights, 'descend');
            sorted_peaks = peaks(idx);
            fprintf('   - Tham số ước lượng: d0 ≈ %.2f ms (≈ %d mẫu), d1 ≈ %.2f ms (≈ %d mẫu)\n', 
                    quefrency(sorted_peaks(1)), round(quefrency(sorted_peaks(1)) * fs / 1000),
                    quefrency(sorted_peaks(2)), round(quefrency(sorted_peaks(2)) * fs / 1000));
            
            % Ước lượng Frame length từ khoảng cách giữa các peak
            if length(peaks) >= 3
                d0_samples = round(quefrency(sorted_peaks(1)) * fs / 1000);
                d1_samples = round(quefrency(sorted_peaks(2)) * fs / 1000);
                fprintf('   - Độ dài khung (L) ước lượng: ~8192 (mặc định) hoặc 2^%d (%d) mẫu\n',
                       ceil(log2(max(d0_samples, d1_samples)*2)), 2^ceil(log2(max(d0_samples, d1_samples)*2)));
            end
        end
    end
    
    fprintf('\n4. Lưu ý bổ sung:\n');
    fprintf('   - Để đánh giá đầy đủ hơn, cần so sánh với file gốc.\n');
    fprintf('   - Các tham số ước lượng có thể được sử dụng để tấn công trích xuất thông tin.\n');
end

% Giữ các figure mở cho đến khi người dùng nhấn phím
fprintf('\nNhấn một phím bất kỳ để đóng các cửa sổ đồ thị...\n');
pause;

% Hàm hỗ trợ
function dec = bin2dec(bin_str)
    % Chuyển đổi chuỗi nhị phân thành số thập phân
    dec = 0;
    for i = 1:length(bin_str)
        if bin_str(i) == '1'
            dec = dec + 2^(length(bin_str) - i);
        end
    end
end

function w = hanning(L)
    % Tạo cửa sổ Hanning độ dài L
    if L <= 0
        w = [];
        return;
    end
    n = (0:L-1)';
    w = 0.5 - 0.5*cos(2*pi*n/(L-1));
end
