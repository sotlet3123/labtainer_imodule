% TẤN CÔNG TRÍCH XUẤT THÔNG TIN GIẤU TIN
close all; clear all; clc;

% Kiểm tra và tải gói signal nếu có
has_signal_pkg = false;
try
    pkg('list');
    if exist('pkg') == 5 % function exists
        pkg_list = pkg('list');
        is_signal_installed = false;
        for i = 1:length(pkg_list)
            if strcmp(pkg_list{i}.name, 'signal')
                is_signal_installed = true;
                has_signal_pkg = true;
                if ~pkg_list{i}.loaded
                    pkg('load', 'signal');
                    fprintf('Đã tải gói signal.\n');
                end
                break;
            end
        end
        if ~is_signal_installed
            fprintf('Cảnh báo: Gói signal không được cài đặt. Sẽ sử dụng các hàm tự cài đặt.\n');
        end
    end
catch
    fprintf('Cảnh báo: Không thể kiểm tra/tải gói signal. Sẽ sử dụng các hàm tự cài đặt.\n');
end

% Hiển thị tiêu đề
fprintf('===== TẤN CÔNG TRÍCH XUẤT THÔNG TIN GIẤU TIN =====\n\n');
fprintf('Chương trình này thực hiện các phương pháp tấn công để trích xuất\n');
fprintf('thông tin giấu tin trong file âm thanh sử dụng phương pháp Echo Hiding.\n\n');

% Cho phép người dùng chọn file âm thanh có giấu tin
fprintf('Chọn file âm thanh có giấu tin từ thư mục audio_out...\n');
[stego_name, stego_path] = uigetfile({'*.wav;*.mp3;*.flac;*.ogg;*.aac', 'Audio Files (*.wav, *.mp3, *.flac, *.ogg, *.aac)'}, 'Chọn file âm thanh có giấu tin', 'audio_out/');

% Kiểm tra xem người dùng đã chọn file hay chưa
if isequal(stego_name, 0)
    fprintf('Người dùng đã hủy việc chọn file.\n');
    return;
end

% Hiển thị thông tin file đã chọn
fprintf('\nĐã chọn file: %s\n', fullfile(stego_path, stego_name));

% Đọc dữ liệu âm thanh
fprintf('\nĐang đọc dữ liệu âm thanh...\n');
try
    [stego_data, fs] = audioread(fullfile(stego_path, stego_name));
    fprintf('Đã đọc dữ liệu âm thanh thành công. Tần số lấy mẫu: %d Hz\n', fs);
catch ME
    fprintf('Lỗi khi đọc file âm thanh: %s\n', ME.message);
    return;
end

% Đảm bảo dữ liệu là mono để phân tích
if size(stego_data, 2) > 1
    fprintf('\nPhát hiện tín hiệu stereo. Chuyển đổi thành mono để phân tích...\n');
    stego_data = mean(stego_data, 2);
end

% Chuẩn hóa dữ liệu
stego_data = stego_data / max(abs(stego_data));

% Tìm kiếm tệp thông số giấu tin
param_file = 'stego_params.txt';
if exist(param_file, 'file')
    fprintf('\nĐọc các tham số từ file %s...\n', param_file);
    fid = fopen(param_file, 'r');
    d0 = str2num(fgetl(fid));
    d1 = str2num(fgetl(fid));
    alpha = str2num(fgetl(fid));
    L = str2num(fgetl(fid));
    len_msg = str2num(fgetl(fid));
    fclose(fid);
    
    fprintf('Đã tìm thấy tham số giấu tin:\n');
    fprintf('- Độ trễ bit 0 (d0): %d\n', d0);
    fprintf('- Độ trễ bit 1 (d1): %d\n', d1);
    fprintf('- Hệ số biên độ (alpha): %.4f\n', alpha);
    fprintf('- Độ dài khung (L): %d\n', L);
    fprintf('- Độ dài thông điệp: %d ký tự\n', len_msg);
    
    use_known_params = true;
else
    % Nếu không tìm thấy file tham số, cần phải ước lượng tham số
    fprintf('\nKhông tìm thấy file tham số. Thực hiện phân tích để ước lượng tham số...\n');
    use_known_params = false;
    % Sử dụng tham số mặc định ban đầu
    d0 = 50;
    d1 = 300;
    alpha = 0.05;
    L = 8*1024;
    len_msg = 0; % Chưa biết
end

% Cho phép người dùng điều chỉnh tham số nếu muốn
adjust_params = input('\nBạn có muốn điều chỉnh tham số trích xuất không? (y/n): ', 's');
if strcmpi(adjust_params, 'y')
    fprintf('\nNhập các tham số mới (nhấn Enter để giữ nguyên giá trị hiện tại):\n');
    
    input_d0 = input(sprintf('Độ trễ bit 0 (d0) [%d]: ', d0));
    if ~isempty(input_d0)
        d0 = input_d0;
    end
    
    input_d1 = input(sprintf('Độ trễ bit 1 (d1) [%d]: ', d1));
    if ~isempty(input_d1)
        d1 = input_d1;
    end
    
    input_L = input(sprintf('Độ dài khung (L) [%d]: ', L));
    if ~isempty(input_L)
        L = input_L;
    end
end

fprintf('\n===== BẮT ĐẦU TẤN CÔNG TRÍCH XUẤT =====\n');

% 1. Ước lượng tham số nếu cần
if ~use_known_params
    fprintf('\n1. ƯỚC LƯỢNG THAM SỐ GIẤU TIN\n');
    
    % Tính cepstrum để phát hiện độ trễ echo
    nfft = 2^nextpow2(length(stego_data));
    stego_fft = fft(stego_data, nfft);
    stego_log_spectrum = log(abs(stego_fft(1:nfft/2+1)) + eps);
    stego_cepstrum = real(ifft(stego_log_spectrum));
    
    % Giới hạn phân tích cepstrum cho quefrencies thấp
    ceps_limit = min(1000, length(stego_cepstrum));
    quefrency = (0:ceps_limit-1) / fs * 1000; % Chuyển đổi sang ms
    
    % Tìm các peak trong cepstrum để xác định độ trễ echo
    zoom_limit = min(find(quefrency >= 50), length(quefrency));
    min_height = 0.1 * max(stego_cepstrum(1:zoom_limit));
    
    % Tìm các peak
    peaks = [];
    peak_heights = [];
    for i = 2:zoom_limit-1
        if stego_cepstrum(i) > stego_cepstrum(i-1) && stego_cepstrum(i) > stego_cepstrum(i+1) && stego_cepstrum(i) > min_height
            if isempty(peaks) || (quefrency(i) - quefrency(peaks(end)) >= 0.5)
                peaks = [peaks, i];
                peak_heights = [peak_heights, stego_cepstrum(i)];
            end
        end
    end
    
    % Hiển thị biểu đồ cepstrum với các peak
    h1 = figure('Name', 'Phân tích Cepstrum để phát hiện độ trễ Echo', 'NumberTitle', 'off', 'Position', [100 100 900 400]);
    plot(quefrency(1:zoom_limit), stego_cepstrum(1:zoom_limit), 'b-', 'LineWidth', 1.2);
    hold on;
    
    % Đánh dấu các peak tìm được
    if ~isempty(peaks)
        for i = 1:length(peaks)
            if peaks(i) <= zoom_limit
                plot(quefrency(peaks(i)), stego_cepstrum(peaks(i)), 'ro', 'MarkerSize', 8, 'LineWidth', 1.5);
                text(quefrency(peaks(i)), stego_cepstrum(peaks(i))*1.1, sprintf('%.2f ms', quefrency(peaks(i))), 'FontSize', 8);
            end
        end
    end
    hold off;
    title('Cepstrum phát hiện Echo (0-50 ms)', 'FontWeight', 'bold');
    xlabel('Quefrency (ms)', 'FontWeight', 'bold');
    ylabel('Biên độ', 'FontWeight', 'bold');
    grid on;
    set(gca, 'FontSize', 10);
    
    % Ước lượng d0 và d1 từ các peak tìm được
    if length(peaks) >= 2
        % Sắp xếp các peak theo chiều cao
        [sorted_heights, idx] = sort(peak_heights, 'descend');
        sorted_peaks = peaks(idx);
        
        % Lấy hai peak cao nhất
        peak1 = sorted_peaks(1);
        peak2 = sorted_peaks(2);
        
        % Chuyển đổi từ ms sang mẫu
        d0_est = round(quefrency(min(peak1, peak2)) * fs / 1000);
        d1_est = round(quefrency(max(peak1, peak2)) * fs / 1000);
        
        fprintf('Đã ước lượng các tham số từ phân tích cepstrum:\n');
        fprintf('- Độ trễ bit 0 (d0): %d (%.2f ms)\n', d0_est, quefrency(min(peak1, peak2)));
        fprintf('- Độ trễ bit 1 (d1): %d (%.2f ms)\n', d1_est, quefrency(max(peak1, peak2)));
        
        % Cập nhật tham số
        d0 = d0_est;
        d1 = d1_est;
    else
        fprintf('Không thể ước lượng đủ tham số từ phân tích cepstrum.\n');
        fprintf('Sử dụng tham số mặc định: d0 = %d, d1 = %d\n', d0, d1);
    end
end

% 2. Thực hiện trích xuất với tham số đã xác định
fprintf('\n2. TRÍCH XUẤT DỮ LIỆU\n');

% Chia tín hiệu thành các khung
n_samples = length(stego_data);
n_frames = floor(n_samples / L);
fprintf('Số lượng khung: %d\n', n_frames);

% Chuẩn bị mảng lưu kết quả
binary_data = '';

% Áp dụng cửa sổ để giảm hiệu ứng biên
window = hanning(L);

% Trích xuất theo khung
fprintf('Tiến hành trích xuất theo khung...\n');
for i = 1:n_frames
    % Lấy khung hiện tại
    start_idx = (i-1)*L + 1;
    end_idx = min(start_idx + L - 1, length(stego_data));
    frame = stego_data(start_idx:end_idx);
    
    if length(frame) < L/2
        continue;  % Bỏ qua khung cuối nếu quá ngắn
    end
    
    % Áp dụng cửa sổ
    frame = frame .* window(1:length(frame));
    
    % Tính cepstrum
    nfft_frame = 2^nextpow2(length(frame));
    frame_fft = fft(frame, nfft_frame);
    frame_log_spectrum = log(abs(frame_fft) + eps);
    frame_cepstrum = real(ifft(frame_log_spectrum));
    
    % Chỉ xét nửa đầu của cepstrum
    frame_cepstrum = frame_cepstrum(1:floor(nfft_frame/2));
    
    % Tính điểm tại các vị trí echo dự kiến
    score0 = 0;
    score1 = 0;
    
    % Tính điểm cho echo bit 0
    d0_pos = min(d0+1, length(frame_cepstrum));
    region0 = max(1, d0_pos-2):min(length(frame_cepstrum), d0_pos+2);
    score0 = max(abs(frame_cepstrum(region0)));
    
    % Tính điểm cho echo bit 1
    d1_pos = min(d1+1, length(frame_cepstrum));
    region1 = max(1, d1_pos-2):min(length(frame_cepstrum), d1_pos+2);
    score1 = max(abs(frame_cepstrum(region1)));
    
    % Xác định bit bằng cách so sánh điểm
    if score0 > score1
        binary_data = [binary_data, '0'];
    else
        binary_data = [binary_data, '1'];
    end
    
    % Hiển thị tiến trình
    if mod(i, 10) == 0
        fprintf('Đã xử lý %d/%d khung (%.1f%%)\n', i, n_frames, i/n_frames*100);
    end
end

fprintf('Hoàn thành trích xuất dữ liệu nhị phân: %d bit\n', length(binary_data));

% 3. Chuyển đổi dữ liệu nhị phân thành văn bản
fprintf('\n3. CHUYỂN ĐỔI DỮ LIỆU NHỊ PHÂN THÀNH VĂN BẢN\n');

% Đảm bảo độ dài là bội số của 8
bin_len = floor(length(binary_data)/8) * 8;
if bin_len < 8
    fprintf('Dữ liệu nhị phân quá ngắn để chuyển đổi thành văn bản.\n');
    return;
end

binary_data = binary_data(1:bin_len);

% Tạo mảng các ký tự
extracted_chars = [];

% Chuyển đổi mỗi nhóm 8 bit thành một ký tự
for i = 1:8:bin_len
    if i+7 <= length(binary_data)
        byte = binary_data(i:i+7);
        dec_val = bin2dec(byte);
        
        % Chỉ lưu các ký tự ASCII in được
        if dec_val >= 32 && dec_val <= 126
            extracted_chars = [extracted_chars, char(dec_val)];
        else
            extracted_chars = [extracted_chars, '?'];
        end
    end
end

fprintf('Đã chuyển đổi thành %d ký tự.\n', length(extracted_chars));

% Hiển thị kết quả trích xuất
fprintf('\n===== KẾT QUẢ TRÍCH XUẤT =====\n\n');
fprintf('Dữ liệu trích xuất:\n');
fprintf('%s\n', extracted_chars);

% 4. Thực hiện tấn công sửa đổi tham số để cải thiện kết quả
fprintf('\n4. THỬ NGHIỆM ĐIỀU CHỈNH THAM SỐ\n');

% Thử nghiệm với các giá trị d0 và d1 khác nhau
fprintf('Thử nghiệm với các tham số d0 và d1 khác nhau...\n');

% Tạo ma trận để lưu kết quả các lần thử
test_range = 5; % Số lượng thử nghiệm mỗi bên
test_step = 5;  % Bước nhảy
n_tests = 2*test_range + 1;
test_results = cell(n_tests, n_tests);

for i = -test_range:test_range
    for j = -test_range:test_range
        % Điều chỉnh d0 và d1
        test_d0 = d0 + i*test_step;
        test_d1 = d1 + j*test_step;
        
        if test_d0 <= 0 || test_d1 <= 0 || test_d0 >= test_d1
            continue;
        end
        
        % Trích xuất với tham số mới
        test_binary = '';
        
        % Chỉ xử lý một số khung ban đầu để tiết kiệm thời gian
        max_test_frames = min(50, n_frames);
        
        for k = 1:max_test_frames
            % Lấy khung hiện tại
            start_idx = (k-1)*L + 1;
            end_idx = min(start_idx + L - 1, length(stego_data));
            frame = stego_data(start_idx:end_idx);
            
            if length(frame) < L/2
                continue;
            end
            
            % Áp dụng cửa sổ
            frame = frame .* window(1:length(frame));
            
            % Tính cepstrum
            nfft_frame = 2^nextpow2(length(frame));
            frame_fft = fft(frame, nfft_frame);
            frame_log_spectrum = log(abs(frame_fft) + eps);
            frame_cepstrum = real(ifft(frame_log_spectrum));
            frame_cepstrum = frame_cepstrum(1:floor(nfft_frame/2));
            
            % Tính điểm tại các vị trí echo dự kiến
            test_d0_pos = min(test_d0+1, length(frame_cepstrum));
            region0 = max(1, test_d0_pos-2):min(length(frame_cepstrum), test_d0_pos+2);
            score0 = max(abs(frame_cepstrum(region0)));
            
            test_d1_pos = min(test_d1+1, length(frame_cepstrum));
            region1 = max(1, test_d1_pos-2):min(length(frame_cepstrum), test_d1_pos+2);
            score1 = max(abs(frame_cepstrum(region1)));
            
            % Xác định bit
            if score0 > score1
                test_binary = [test_binary, '0'];
            else
                test_binary = [test_binary, '1'];
            end
        end
        
        % Chuyển đổi dữ liệu nhị phân thành văn bản
        test_bin_len = floor(length(test_binary)/8) * 8;
        if test_bin_len >= 8
            test_binary = test_binary(1:test_bin_len);
            test_chars = '';
            
            for k = 1:8:test_bin_len
                if k+7 <= length(test_binary)
                    byte = test_binary(k:k+7);
                    dec_val = bin2dec(byte);
                    
                    if dec_val >= 32 && dec_val <= 126
                        test_chars = [test_chars, char(dec_val)];
                    else
                        test_chars = [test_chars, '?'];
                    end
                end
            end
            
            % Lưu kết quả
            idx_i = i + test_range + 1;
            idx_j = j + test_range + 1;
            test_results{idx_i, idx_j} = test_chars;
        end
    end
end

% Hiển thị các kết quả thử nghiệm
fprintf('\nKết quả thử nghiệm với các tham số khác nhau:\n');
fprintf('(Hiển thị 10 ký tự đầu tiên của mỗi kết quả)\n\n');

fprintf('%-10s', 'd1 \\ d0');
for i = -test_range:test_range
    test_d0 = d0 + i*test_step;
    if test_d0 > 0
        fprintf('%-10d', test_d0);
    end
end
fprintf('\n');

for j = -test_range:test_range
    test_d1 = d1 + j*test_step;
    if test_d1 > 0
        fprintf('%-10d', test_d1);
        
        for i = -test_range:test_range
            test_d0 = d0 + i*test_step;
            
            if test_d0 <= 0 || test_d1 <= 0 || test_d0 >= test_d1
                fprintf('%-10s', '-');
            else
                idx_i = i + test_range + 1;
                idx_j = j + test_range + 1;
                
                if ~isempty(test_results{idx_i, idx_j})
                    result_str = test_results{idx_i, idx_j};
                    if length(result_str) > 10
                        result_str = result_str(1:10);
                    end
                    fprintf('%-10s', result_str);
                else
                    fprintf('%-10s', '-');
                end
            end
        end
        fprintf('\n');
    end
end

% 5. Lưu kết quả trích xuất vào file
output_file = 'extracted_message.txt';
fid = fopen(output_file, 'w');
fprintf(fid, '%s', extracted_chars);
fclose(fid);
fprintf('\nĐã lưu kết quả trích xuất vào file: %s\n', output_file);

% Kết luận
fprintf('\n===== KẾT LUẬN =====\n');
fprintf('Đã thực hiện tấn công trích xuất thông tin giấu tin với tham số:\n');
fprintf('- Độ trễ bit 0 (d0): %d\n', d0);
fprintf('- Độ trễ bit 1 (d1): %d\n', d1);
fprintf('- Độ dài khung (L): %d\n', L);
fprintf('\nĐã trích xuất được %d ký tự văn bản.\n', length(extracted_chars));

% Đánh giá kết quả
fprintf('\nĐánh giá kết quả trích xuất:\n');

% Kiểm tra xem kết quả có phải là văn bản có nghĩa không
printable_ratio = sum(extracted_chars >= 32 & extracted_chars <= 126) / length(extracted_chars);
letter_ratio = sum((extracted_chars >= 'a' & extracted_chars <= 'z') | (extracted_chars >= 'A' & extracted_chars <= 'Z')) / length(extracted_chars);
space_ratio = sum(extracted_chars == ' ') / length(extracted_chars);

fprintf('- Tỷ lệ ký tự in được: %.2f%%\n', printable_ratio * 100);
fprintf('- Tỷ lệ chữ cái: %.2f%%\n', letter_ratio * 100);
fprintf('- Tỷ lệ dấu cách: %.2f%%\n', space_ratio * 100);

if printable_ratio > 0.8 && letter_ratio > 0.4 && space_ratio > 0.05 && space_ratio < 0.3
    fprintf('\nKết quả trích xuất có khả năng cao là văn bản có nghĩa.\n');
elseif printable_ratio > 0.5 && letter_ratio > 0.2
    fprintf('\nKết quả trích xuất có thể là văn bản có nghĩa, nhưng có một số lỗi.\n');
else
    fprintf('\nKết quả trích xuất có thể không chính xác hoặc cần tiếp tục điều chỉnh tham số.\n');
end

% Giữ các figure mở cho đến khi người dùng nhấn phím
fprintf('\nNhấn một phím bất kỳ để đóng các cửa sổ đồ thị...\n');
pause;

% Hàm hỗ trợ
function dec = bin2dec(bin_str)
    % Chuyển đổi chuỗi nhị phân thành số thập phân
    dec = 0;
    for i = 1:length(bin_str)
        if bin_str(i) == '1'
            dec = dec + 2^(length(bin_str) - i);
        end
    end
end

function w = hanning(L)
    % Tạo cửa sổ Hanning độ dài L
    if L <= 0
        w = [];
        return;
    end
    n = (0:L-1)';
    w = 0.5 - 0.5*cos(2*pi*n/(L-1));
end

