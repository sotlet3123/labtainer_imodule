function data = ts_dec(xsig, d0, d1, pr)
%TS_DEC Decode hidden message using Time-Spread Echo Hiding Technique
%
%   INPUT VARIABLES
%       xsig : Stego signal frames
%       d0   : Delay rate for bit0
%       d1   : Delay rate for bit1
%       pr   : Pseudorandom sequence (không sử dụng trong phiên bản mới)
%
%   OUTPUT VARIABLES
%       data : Retrieved binary sequence
%
%   Kadir Tekeli (kadir.tekeli@outlook.com)

% Phiên bản mới sử dụng phương pháp phát hiện echo qua cepstrum
[L, N] = size(xsig);

% Khởi tạo mảng kết quả
data = zeros(1, N);

% Tạo vị trí echo lặp lại
echoes0 = [d0, 2*d0, 3*d0];  % Vị trí echo cho bit 0
echoes1 = [d1, 2*d1, 3*d1];  % Vị trí echo cho bit 1

% Lọc các vị trí nằm ngoài phạm vi hợp lý
valid_echoes0 = echoes0(echoes0 > 10 & echoes0 < L/2);
valid_echoes1 = echoes1(echoes1 > 10 & echoes1 < L/2);

% Xử lý từng khung
for i = 1:N
    % Lấy khung hiện tại
    frame = xsig(:,i);
    
    % Chuẩn hóa khung
    frame = frame - mean(frame);
    frame = frame / (max(abs(frame)) + eps);
    
    % Áp dụng cửa sổ để giảm hiệu ứng biên
    frame = frame .* hamming(length(frame));
    
    % Tính cepstrum
    ceps = cepstrum(frame);
    
    % Tính tổng điểm tại các vị trí echo dự kiến
    score0 = 0;
    score1 = 0;
    
    % Điểm cho bit 0
    for j = 1:length(valid_echoes0)
        pos = valid_echoes0(j);
        if pos < length(ceps)
            region = max(1, pos-2):min(length(ceps), pos+2);
            score0 = score0 + max(abs(ceps(region)));
        end
    end
    
    % Điểm cho bit 1
    for j = 1:length(valid_echoes1)
        pos = valid_echoes1(j);
        if pos < length(ceps)
            region = max(1, pos-2):min(length(ceps), pos+2);
            score1 = score1 + max(abs(ceps(region)));
        end
    end
    
    % Xác định bit bằng cách so sánh điểm
    if score0 > score1
        data(i) = 0;
    else
        data(i) = 1;
    end
end

% Chuyển đổi sang chuỗi ký tự
data = char('0' + data);

end

function c = cepstrum(x)
% Tính cepstrum phức
N = length(x);
X = fft(x, 2*N);
logX = log(abs(X) + eps);
c = real(ifft(logX));
c = c(1:N/2);  % Chỉ giữ nửa đầu (quefrencies có liên quan)
end

function w = hamming(L)
% Tạo cửa sổ Hamming độ dài L
n = (0:L-1)';
w = 0.54 - 0.46*cos(2*pi*n/(L-1));
end

function acf = compute_simple_acf(x, max_lag)
% Tính tự tương quan đơn giản
N = length(x);
max_lag = min(max_lag, N-1);
acf = zeros(max_lag, 1);

for lag = 1:max_lag
    % Tính tương quan trực tiếp
    acf(lag) = sum(x(1:N-lag) .* x(1+lag:N)) / (N-lag);
end

% Chuẩn hóa
acf = acf / max(abs(acf));
end

function auto_corr = compute_autocorr(x)
% Compute autocorrelation using FFT
N = length(x);
X = fft(x, 2*N);
P = X .* conj(X);
auto_corr = real(ifft(P));
auto_corr = auto_corr(1:N);  % Only consider positive lags
end

function w = hann_window(L)
% Manual implementation of Hanning window
if L <= 0
    w = [];
    return;
end

if L == 1
    w = 1;
    return;
end

% Create window
n = (0:L-1)';
w = 0.5 * (1 - cos(2*pi*n/(L-1)));
end

function c = xcorr(x, scaling)
% Simple implementation of cross-correlation
N = length(x);
X = fft(x, 2*N);
S = X .* conj(X);
c = real(ifft(S));

% Rearrange to center at zero lag
c = [c(N+1:end); c(1:N)];

% Apply scaling
if nargin > 1 && strcmp(scaling, 'biased')
    c = c / N;
end
end 