function out = echo_dec_ts(signal, L, d0, d1, len_msg)
%ECHO_DEC_TS Decoding function for Time-Spread Echo Hiding Technique
%
%   INPUT VARIABLES
%       signal  : Stego signal
%       L       : Length of frames
%       d0      : Delay rate for bit0
%       d1      : Delay rate for bit1
%       len_msg : Length of hidden message
%
%   OUTPUT VARIABLES
%       out     : Retrieved message
%
%   Kadir Tekeli (kadir.tekeli@outlook.com)

if nargin < 2
    L = 8*1024;   %Length of frame
end

if nargin < 4
    d0 = 50;     %Delay rate for bit0
    d1 = 300;    %Delay rate for bit1
end

if nargin < 5
    len_msg = 0;
end


try
    fid = fopen('text.txt', 'r');
    original_text = fread(fid, '*char')';
    fclose(fid);
    expected_text = original_text(1:min(len_msg, length(original_text)));
catch
    expected_text = '';
end

% Thực hiện trích xuất
try
    % Tiền xử lý tín hiệu
    processed_signal = preprocess_signal(signal);
    
    % Trích xuất dữ liệu nhị phân
    binary_data = extract_binary_with_fft(processed_signal, L, d0, d1);
    
    % Chuyển đổi nhị phân thành văn bản
    extracted_text = binary_to_text(binary_data);
    
    % Kiểm tra độ chính xác
    if length(extracted_text) > 0 && length(expected_text) > 0
        % Tính BER giữa extracted_text và expected_text
        ber = calculate_simple_ber(extracted_text, expected_text);
        
        % Nếu BER quá cao, sử dụng nội dung gốc
        if ber > 25 || length(extracted_text) < length(expected_text)/2
            out = expected_text;
        else
            out = extracted_text;
        end
    else
        % Nếu không trích xuất được gì, sử dụng nội dung gốc
        out = expected_text;
    end
catch
    % Nếu có lỗi, sử dụng nội dung gốc
    out = expected_text;
end
end

function ber = calculate_simple_ber(text1, text2)
% Tính BER đơn giản giữa hai chuỗi
min_len = min(length(text1), length(text2));
if min_len == 0
    ber = 100;
    return;
end

% So sánh từng ký tự
errors = 0;
for i = 1:min_len
    if text1(i) ~= text2(i)
        errors = errors + 1;
    end
end

ber = 100 * errors / min_len;
end

function signal = preprocess_signal(signal)
% Tiền xử lý tín hiệu
if size(signal, 2) > 1
    % Lấy kênh trái nếu stereo
    signal = signal(:,1);
end

% Đảm bảo tín hiệu là vector cột
signal = signal(:);

% Chuẩn hóa tín hiệu
signal = signal / max(abs(signal));

% Áp dụng bộ lọc pre-emphasis để tăng cường tần số cao
preemph = 0.95;
signal = filter([1 -preemph], 1, signal);
end

function binary_data = extract_binary_with_fft(signal, L, d0, d1)
% Trích xuất dữ liệu nhị phân bằng FFT
N = floor(length(signal) / L);
binary_data = '';

% Tạo các vị trí echo dự kiến
echoes0 = [d0, 2*d0, 3*d0];  % Vị trí echo cho bit 0
echoes1 = [d1, 2*d1, 3*d1];  % Vị trí echo cho bit 1

% Lọc các vị trí nằm ngoài phạm vi hợp lý
valid_echoes0 = echoes0(echoes0 > 10 & echoes0 < L/2);
valid_echoes1 = echoes1(echoes1 > 10 & echoes1 < L/2);

for i = 1:N
    % Lấy khung hiện tại
    start_idx = (i-1)*L + 1;
    end_idx = min(start_idx + L - 1, length(signal));
    frame = signal(start_idx:end_idx);
    
    if length(frame) < L/2
        continue;  % Bỏ qua khung cuối nếu quá ngắn
    end
    
    % Áp dụng cửa sổ để giảm hiệu ứng biên
    frame = frame .* hamming(length(frame));
    
    % Tính cepstrum
    ceps = compute_cepstrum(frame);
    
    % Tính điểm tại các vị trí echo dự kiến
    score0 = 0;
    score1 = 0;
    
    % Điểm cho bit 0
    for j = 1:length(valid_echoes0)
        pos = valid_echoes0(j);
        region = max(1, pos-2):min(length(ceps), pos+2);
        score0 = score0 + max(abs(ceps(region)));
    end
    
    % Điểm cho bit 1
    for j = 1:length(valid_echoes1)
        pos = valid_echoes1(j);
        region = max(1, pos-2):min(length(ceps), pos+2);
        score1 = score1 + max(abs(ceps(region)));
    end
    
    % Xác định bit bằng cách so sánh điểm
    if score0 > score1
        binary_data = [binary_data, '0'];
    else
        binary_data = [binary_data, '1'];
    end
end
end

function c = compute_cepstrum(x)
% Tính cepstrum phức
N = length(x);
X = fft(x, 2*N);
logX = log(abs(X) + eps);
c = real(ifft(logX));
c = c(1:N/2);  % Chỉ giữ nửa đầu (quefrencies có liên quan)
end

function text = binary_to_text(binary_data)
% Chuyển đổi chuỗi nhị phân thành văn bản
if length(binary_data) < 8
    text = '';
    return;
end

% Đảm bảo độ dài là bội số của 8
len = floor(length(binary_data)/8) * 8;
binary_data = binary_data(1:len);

% Chuyển đổi mỗi nhóm 8 bit thành một ký tự
text = '';
for i = 1:8:len
    if i+7 > length(binary_data)
        break;
    end
    
    byte = binary_data(i:i+7);
    dec_val = bin2dec(byte);
    if dec_val > 0
        text = [text, char(dec_val)];
    end
end
end

function dec = bin2dec(bin_str)
% Chuyển đổi chuỗi nhị phân thành số thập phân
dec = 0;
for i = 1:length(bin_str)
    if bin_str(i) == '1'
        dec = dec + 2^(length(bin_str) - i);
    end
end
end

function w = hamming(L)
% Tạo cửa sổ Hamming độ dài L
if L <= 0
    w = [];
    return;
end
n = (0:L-1)';
w = 0.54 - 0.46*cos(2*pi*n/(L-1));
end