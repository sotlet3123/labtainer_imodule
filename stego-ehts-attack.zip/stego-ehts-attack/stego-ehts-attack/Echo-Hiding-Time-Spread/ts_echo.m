function [echo_zro, echo_one] = ts_echo(signal, d0, d1, pr)
%TS_ECHO Generate echo signals for Time-Spread Echo Hiding Technique
%
%   INPUT VARIABLES
%       signal : Cover signal
%       d0     : Delay rate for bit0
%       d1     : Delay rate for bit1
%       pr     : Pseudorandom sequence
%
%   OUTPUT VARIABLES
%       echo_zro : Echo signal for bit0
%       echo_one : Echo signal for bit1
%
%   Kadir Tekeli (kadir.tekeli@outlook.com)

[s.len, s.ch] = size(signal);
Lp = length(pr);

% Initialize echo kernels
h0 = zeros(d0 + Lp, 1);
h1 = zeros(d1 + Lp, 1);

% Generate echo kernels with pseudorandom sequence
h0(1:Lp) = pr;
h0(d0 + (1:Lp)) = pr;

h1(1:Lp) = pr;
h1(d1 + (1:Lp)) = pr;

% Generate echo signals using convolution
echo_zro = zeros(s.len, s.ch);
echo_one = zeros(s.len, s.ch);

for ch = 1:s.ch
    echo_zro(:,ch) = conv(signal(:,ch), h0, 'same');
    echo_one(:,ch) = conv(signal(:,ch), h1, 'same');
end

end 